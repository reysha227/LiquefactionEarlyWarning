﻿using Microsoft.Maui.Controls;
using SkiaSharp;
using SkiaSharp.Views.Maui;
using SkiaSharp.Views.Maui.Controls;

namespace LiquefactionEarlyWarning.Controls;

public class LineChartCanvas : SKCanvasView
{
    public IList<double> Values { get; set; } = new List<double>();

    public string ChartTitle { get; set; } = "Tren Risiko";

    public void UpdateValues(IList<double> values)
    {
        Values = values;
        InvalidateSurface();
    }

    protected override void OnPaintSurface(SKPaintSurfaceEventArgs e)
    {
        base.OnPaintSurface(e);

        SKCanvas canvas = e.Surface.Canvas;
        SKImageInfo info = e.Info;

        canvas.Clear(SKColor.Parse("#101832"));

        float width = info.Width;
        float height = info.Height;

        float left = 42;
        float top = 42;
        float right = width - 24;
        float bottom = height - 34;

        using SKPaint gridPaint = new()
        {
            Color = SKColor.Parse("#26304F"),
            StrokeWidth = 1.5f,
            IsAntialias = true
        };

        for (int i = 0; i <= 4; i++)
        {
            float y = top + ((bottom - top) * i / 4f);
            canvas.DrawLine(left, y, right, y, gridPaint);
        }

        using SKPaint titlePaint = new()
        {
            Color = SKColors.White,
            TextSize = 22,
            IsAntialias = true,
            FakeBoldText = true
        };

        canvas.DrawText(ChartTitle, left, 26, titlePaint);

        if (Values == null || Values.Count < 2)
        {
            using SKPaint emptyPaint = new()
            {
                Color = SKColor.Parse("#BFD7FF"),
                TextSize = 18,
                IsAntialias = true
            };

            canvas.DrawText("Menunggu data...", left, height / 2f, emptyPaint);
            return;
        }

        using SKPaint linePaint = new()
        {
            Color = SKColor.Parse("#00F0FF"),
            StrokeWidth = 4,
            IsAntialias = true,
            Style = SKPaintStyle.Stroke,
            StrokeCap = SKStrokeCap.Round
        };

        using SKPath path = new();

        int count = Values.Count;

        for (int i = 0; i < count; i++)
        {
            double value = Math.Clamp(Values[i], 0, 100);

            float x = left + ((right - left) * i / (count - 1));
            float y = bottom - (float)((value / 100.0) * (bottom - top));

            if (i == 0)
            {
                path.MoveTo(x, y);
            }
            else
            {
                path.LineTo(x, y);
            }
        }

        canvas.DrawPath(path, linePaint);

        using SKPaint dotPaint = new()
        {
            Color = SKColor.Parse("#FF5CA8"),
            IsAntialias = true
        };

        for (int i = 0; i < count; i++)
        {
            double value = Math.Clamp(Values[i], 0, 100);

            float x = left + ((right - left) * i / (count - 1));
            float y = bottom - (float)((value / 100.0) * (bottom - top));

            canvas.DrawCircle(x, y, 5, dotPaint);
        }
    }
}