﻿using Microsoft.Maui.Controls;
using SkiaSharp;
using SkiaSharp.Views.Maui;
using SkiaSharp.Views.Maui.Controls;

namespace LiquefactionEarlyWarning.Controls;

public class GaugeCanvas : SKCanvasView
{
    public static readonly BindableProperty ValueProperty =
        BindableProperty.Create(
            nameof(Value),
            typeof(double),
            typeof(GaugeCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public static readonly BindableProperty StatusProperty =
        BindableProperty.Create(
            nameof(Status),
            typeof(string),
            typeof(GaugeCanvas),
            "Aman",
            propertyChanged: OnCanvasPropertyChanged);

    public double Value
    {
        get => (double)GetValue(ValueProperty);
        set => SetValue(ValueProperty, value);
    }

    public string Status
    {
        get => (string)GetValue(StatusProperty);
        set => SetValue(StatusProperty, value);
    }

    private static void OnCanvasPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is GaugeCanvas canvas)
        {
            canvas.InvalidateSurface();
        }
    }

    protected override void OnPaintSurface(SKPaintSurfaceEventArgs e)
    {
        base.OnPaintSurface(e);

        SKCanvas canvas = e.Surface.Canvas;
        SKImageInfo info = e.Info;

        canvas.Clear(SKColors.Transparent);

        float width = info.Width;
        float height = info.Height;

        float centerX = width / 2f;
        float centerY = height * 0.78f;
        float radius = Math.Min(width * 0.38f, height * 0.65f);

        double safeValue = Math.Clamp(Value, 0, 100);

        SKRect arcRect = new(
            centerX - radius,
            centerY - radius,
            centerX + radius,
            centerY + radius);

        using SKPaint basePaint = new()
        {
            Color = SKColor.Parse("#26304F"),
            IsAntialias = true,
            StrokeWidth = 24,
            Style = SKPaintStyle.Stroke,
            StrokeCap = SKStrokeCap.Round
        };

        using SKPaint valuePaint = new()
        {
            Color = GetStatusColor(Status),
            IsAntialias = true,
            StrokeWidth = 24,
            Style = SKPaintStyle.Stroke,
            StrokeCap = SKStrokeCap.Round
        };

        canvas.DrawArc(arcRect, 180, 180, false, basePaint);
        canvas.DrawArc(arcRect, 180, (float)(safeValue / 100.0 * 180.0), false, valuePaint);

        using SKPaint numberPaint = new()
        {
            Color = SKColors.White,
            TextSize = 46,
            IsAntialias = true,
            TextAlign = SKTextAlign.Center,
            FakeBoldText = true
        };

        using SKPaint labelPaint = new()
        {
            Color = SKColor.Parse("#BFD7FF"),
            TextSize = 22,
            IsAntialias = true,
            TextAlign = SKTextAlign.Center
        };

        using SKPaint statusPaint = new()
        {
            Color = GetStatusColor(Status),
            TextSize = 26,
            IsAntialias = true,
            TextAlign = SKTextAlign.Center,
            FakeBoldText = true
        };

        canvas.DrawText($"{safeValue:F1}", centerX, centerY - 30, numberPaint);
        canvas.DrawText("Risk Score", centerX, centerY + 8, labelPaint);
        canvas.DrawText(Status, centerX, centerY + 48, statusPaint);
    }

    private static SKColor GetStatusColor(string status)
    {
        return status switch
        {
            "Aman" => SKColor.Parse("#42E6A4"),
            "Waspada" => SKColor.Parse("#FFB86B"),
            "Bahaya" => SKColor.Parse("#FF4D6D"),
            _ => SKColor.Parse("#00F0FF")
        };
    }
}