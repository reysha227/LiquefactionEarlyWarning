﻿using Microsoft.Maui.Controls;
using SkiaSharp;
using SkiaSharp.Views.Maui;
using SkiaSharp.Views.Maui.Controls;

namespace LiquefactionEarlyWarning.Controls;

public class RiskMapCanvas : SKCanvasView
{
    public static readonly BindableProperty RiskScoreProperty =
        BindableProperty.Create(
            nameof(RiskScore),
            typeof(double),
            typeof(RiskMapCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public static readonly BindableProperty StatusProperty =
        BindableProperty.Create(
            nameof(Status),
            typeof(string),
            typeof(RiskMapCanvas),
            "Aman",
            propertyChanged: OnCanvasPropertyChanged);

    public static readonly BindableProperty PorePressureProperty =
        BindableProperty.Create(
            nameof(PorePressure),
            typeof(double),
            typeof(RiskMapCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public static readonly BindableProperty VibrationProperty =
        BindableProperty.Create(
            nameof(Vibration),
            typeof(double),
            typeof(RiskMapCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public double RiskScore
    {
        get => (double)GetValue(RiskScoreProperty);
        set => SetValue(RiskScoreProperty, value);
    }

    public string Status
    {
        get => (string)GetValue(StatusProperty);
        set => SetValue(StatusProperty, value);
    }

    public double PorePressure
    {
        get => (double)GetValue(PorePressureProperty);
        set => SetValue(PorePressureProperty, value);
    }

    public double Vibration
    {
        get => (double)GetValue(VibrationProperty);
        set => SetValue(VibrationProperty, value);
    }

    private static void OnCanvasPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is RiskMapCanvas canvas)
        {
            canvas.InvalidateSurface();
        }
    }

    protected override void OnPaintSurface(SKPaintSurfaceEventArgs e)
    {
        base.OnPaintSurface(e);

        SKCanvas canvas = e.Surface.Canvas;
        SKImageInfo info = e.Info;

        canvas.Clear(SKColor.Parse("#101832"));

        float width = info.Width;
        float height = info.Height;

        DrawGrid(canvas, width, height);

        DrawZone(canvas, 20, 48, width * 0.30f, height * 0.60f, "#42E6A4", "AMAN");
        DrawZone(canvas, width * 0.36f, 48, width * 0.30f, height * 0.60f, "#FFB86B", "WASPADA");
        DrawZone(canvas, width * 0.70f, 48, width * 0.25f, height * 0.60f, "#FF4D6D", "BAHAYA");

        float markerX = (float)Math.Clamp((PorePressure / 120.0) * width, 26, width - 26);
        float markerY = (float)Math.Clamp(height - ((Vibration / 1.2) * height), 62, height - 36);

        using SKPaint pulsePaint = new()
        {
            Color = GetStatusColor(Status).WithAlpha(85),
            IsAntialias = true
        };

        using SKPaint markerPaint = new()
        {
            Color = GetStatusColor(Status),
            IsAntialias = true
        };

        canvas.DrawCircle(markerX, markerY, 25, pulsePaint);
        canvas.DrawCircle(markerX, markerY, 11, markerPaint);

        using SKPaint titlePaint = new()
        {
            Color = SKColors.White,
            TextSize = 25,
            IsAntialias = true,
            FakeBoldText = true
        };

        canvas.DrawText("Risk Map / Zona Risiko", 24, 32, titlePaint);

        using SKPaint axisPaint = new()
        {
            Color = SKColor.Parse("#BFD7FF"),
            TextSize = 17,
            IsAntialias = true
        };

        canvas.DrawText("Tekanan Air Pori →", 24, height - 16, axisPaint);

        canvas.Save();
        canvas.RotateDegrees(-90);
        canvas.DrawText("Vibrasi →", -height + 24, 18, axisPaint);
        canvas.Restore();
    }

    private static void DrawGrid(SKCanvas canvas, float width, float height)
    {
        using SKPaint gridPaint = new()
        {
            Color = SKColor.Parse("#26304F"),
            StrokeWidth = 2,
            IsAntialias = true
        };

        for (int i = 1; i < 6; i++)
        {
            float x = width * i / 6f;
            float y = height * i / 6f;

            canvas.DrawLine(x, 0, x, height, gridPaint);
            canvas.DrawLine(0, y, width, y, gridPaint);
        }
    }

    private static void DrawZone(
        SKCanvas canvas,
        float x,
        float y,
        float zoneWidth,
        float zoneHeight,
        string colorHex,
        string label)
    {
        SKRect rect = new(x, y, x + zoneWidth, y + zoneHeight);

        using SKPaint fillPaint = new()
        {
            Color = SKColor.Parse(colorHex).WithAlpha(42),
            IsAntialias = true
        };

        using SKPaint strokePaint = new()
        {
            Color = SKColor.Parse(colorHex).WithAlpha(150),
            IsAntialias = true,
            StrokeWidth = 3,
            Style = SKPaintStyle.Stroke
        };

        canvas.DrawRoundRect(rect, 24, 24, fillPaint);
        canvas.DrawRoundRect(rect, 24, 24, strokePaint);

        using SKPaint textPaint = new()
        {
            Color = SKColor.Parse(colorHex),
            TextSize = 20,
            IsAntialias = true,
            FakeBoldText = true
        };

        canvas.DrawText(label, x + 16, y + 30, textPaint);
    }

    private static SKColor GetStatusColor(string status)
    {
        return status switch
        {
            "Aman" => SKColor.Parse("#42E6A4"),
            "Waspada" => SKColor.Parse("#FFB86B"),
            "Bahaya" => SKColor.Parse("#FF4D6D"),
            _ => SKColor.Parse("#00F0FF")
        };
    }
}