﻿using Microsoft.Maui.Controls;
using SkiaSharp;
using SkiaSharp.Views.Maui;
using SkiaSharp.Views.Maui.Controls;

namespace LiquefactionEarlyWarning.Controls;

public class BarChartCanvas : SKCanvasView
{
    public static readonly BindableProperty FuzzyScoreProperty =
        BindableProperty.Create(
            nameof(FuzzyScore),
            typeof(double),
            typeof(BarChartCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public static readonly BindableProperty AnnScoreProperty =
        BindableProperty.Create(
            nameof(AnnScore),
            typeof(double),
            typeof(BarChartCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public static readonly BindableProperty FinalScoreProperty =
        BindableProperty.Create(
            nameof(FinalScore),
            typeof(double),
            typeof(BarChartCanvas),
            0.0,
            propertyChanged: OnCanvasPropertyChanged);

    public double FuzzyScore
    {
        get => (double)GetValue(FuzzyScoreProperty);
        set => SetValue(FuzzyScoreProperty, value);
    }

    public double AnnScore
    {
        get => (double)GetValue(AnnScoreProperty);
        set => SetValue(AnnScoreProperty, value);
    }

    public double FinalScore
    {
        get => (double)GetValue(FinalScoreProperty);
        set => SetValue(FinalScoreProperty, value);
    }

    private static void OnCanvasPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is BarChartCanvas canvas)
        {
            canvas.InvalidateSurface();
        }
    }

    protected override void OnPaintSurface(SKPaintSurfaceEventArgs e)
    {
        base.OnPaintSurface(e);

        SKCanvas canvas = e.Surface.Canvas;
        SKImageInfo info = e.Info;

        canvas.Clear(SKColor.Parse("#101832"));

        using SKPaint titlePaint = new()
        {
            Color = SKColors.White,
            TextSize = 22,
            IsAntialias = true,
            FakeBoldText = true
        };

        canvas.DrawText("Fuzzy vs ANN vs Final", 24, 30, titlePaint);

        float width = info.Width;
        float height = info.Height;
        float chartBottom = height - 34;
        float chartTop = 56;
        float barWidth = width / 8f;

        DrawBar(canvas, 1.4f * barWidth, chartTop, chartBottom, barWidth, FuzzyScore, "#00F0FF", "Fuzzy");
        DrawBar(canvas, 3.5f * barWidth, chartTop, chartBottom, barWidth, AnnScore, "#BC6CFF", "ANN");
        DrawBar(canvas, 5.6f * barWidth, chartTop, chartBottom, barWidth, FinalScore, "#FF5CA8", "Final");
    }

    private static void DrawBar(
        SKCanvas canvas,
        float x,
        float top,
        float bottom,
        float barWidth,
        double value,
        string colorHex,
        string label)
    {
        double safeValue = Math.Clamp(value, 0, 100);

        float maxHeight = bottom - top;
        float barHeight = (float)((safeValue / 100.0) * maxHeight);

        SKRect backRect = new(x, top, x + barWidth, bottom);
        SKRect barRect = new(x, bottom - barHeight, x + barWidth, bottom);

        using SKPaint backPaint = new()
        {
            Color = SKColor.Parse("#26304F"),
            IsAntialias = true
        };

        using SKPaint barPaint = new()
        {
            Color = SKColor.Parse(colorHex),
            IsAntialias = true
        };

        canvas.DrawRoundRect(backRect, 14, 14, backPaint);
        canvas.DrawRoundRect(barRect, 14, 14, barPaint);

        using SKPaint labelPaint = new()
        {
            Color = SKColors.White,
            TextSize = 16,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true,
            FakeBoldText = true
        };

        canvas.DrawText(label, x + barWidth / 2f, bottom + 22, labelPaint);

        using SKPaint valuePaint = new()
        {
            Color = SKColor.Parse(colorHex),
            TextSize = 17,
            TextAlign = SKTextAlign.Center,
            IsAntialias = true
        };

        canvas.DrawText($"{safeValue:F0}", x + barWidth / 2f, bottom - barHeight - 10, valuePaint);
    }
}