﻿using LiquefactionEarlyWarning.Pages;

namespace LiquefactionEarlyWarning;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        Routing.RegisterRoute("FaceEnrollPage", typeof(FaceEnrollPage));
        Routing.RegisterRoute("FaceScanPage", typeof(FaceScanPage));
        Routing.RegisterRoute("MainDashboardPage", typeof(MainDashboardPage));
    }
}