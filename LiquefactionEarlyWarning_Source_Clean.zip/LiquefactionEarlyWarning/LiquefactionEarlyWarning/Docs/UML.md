# UML Utama - LiquefactionEarlyWarning

Judul program:
Sistem Peringatan Dini Potensi Likuefaksi Tanah Berbasis Monitoring Tekanan Air Pori (Pore Water Pressure) dan Vibrasi Tanah Menggunakan Sensor Piezoelektrik.

## 1. Class Diagram Mermaid

```mermaid
classDiagram
    class RegisterPage {
        -AppDatabase database
        -AuthService authService
        -NlpApiService nlpApiService
        -NlpAccessPolicy nlpAccessPolicy
        +OnRegisterClicked()
        +OnLoginClicked()
        +OnNlpInfoClicked()
        +ClearForm()
    }

    class FaceScanPage {
        -AppDatabase database
        -FaceScanService faceScanService
        +Username
        +Role
        +StartFaceScanAsync()
        +ScanLoopAsync()
        +ShowAccessAcceptedAsync()
        +ShowAccessDeniedAsync()
    }

    class MainDashboardPage {
        -SensorSimulationService sensorService
        -FuzzyRiskEngine fuzzyEngine
        -SimpleAnnRiskEngine annEngine
        -NlpApiService nlpService
        -NlpAccessPolicy nlpAccessPolicy
        -AppDatabase database
        +OnAnalyzeClicked()
        +RunAnalysisAsync()
        +OnSaveClicked()
        +OnLogoutClicked()
    }

    class UserAccount {
        +Id
        +Username
        +PasswordHash
        +Role
        +FaceImagePath
        +FaceImageBytes
        +IsActive
    }

    class SensorReading {
        +Id
        +Timestamp
        +PoreWaterPressureKPa
        +VibrationAmplitude
        +GroundAccelerationG
        +Source
        +Notes
    }

    class RiskResult {
        +Id
        +SensorReadingId
        +FuzzyScore
        +AnnScore
        +FinalRiskScore
        +RiskLevel
        +TechnicalExplanation
        +MitigationRecommendation
    }

    class NlpResponse {
        +Id
        +RiskResultId
        +SimpleExplanation
        +CreatedAt
    }

    class AppDatabase {
        -SQLiteAsyncConnection database
        +SaveUserAsync()
        +GetUserByUsernameAsync()
        +SaveSensorReadingAsync()
        +SaveRiskResultAsync()
        +SaveNlpResponseAsync()
    }

    class AuthService {
        -AppDatabase database
        +RegisterAsync()
        +LoginAsync()
        -HashPassword()
    }

    class FaceScanService {
        +CalculateSimilarity()
        -ExtractFeatureVector()
        -CompareFeatureVectors()
    }

    class NlpApiService {
        -HttpClient httpClient
        +AskAsync()
        +GeneratePublicInfoAsync()
        +GenerateMitigationTextAsync()
        +CheckBypassIntentAsync()
        +ExplainRiskAsync()
    }

    class NlpAccessPolicy {
        +CanAccessPublicInfo()
        +CanAccessDashboardNlp()
        +GetNlpMode()
    }

    class FuzzyRiskEngine {
        +Evaluate()
        -Low()
        -High()
        -Triangle()
    }

    class SimpleAnnRiskEngine {
        +FeedForward()
        +Train()
        +PredictRisk()
        -Sigmoid()
    }

    class AiApiFacade {
        -FuzzyRiskEngine fuzzyRiskEngine
        -SimpleAnnRiskEngine annRiskEngine
        -NlpApiService nlpApiService
        +AnalyzeWithFuzzyAsync()
        +AnalyzeWithAnnAsync()
        +AskNlpAsync()
        +GenerateFinalDecisionAsync()
    }

    class SensorSimulationService {
        +GenerateNormalCondition()
        +GenerateWarningCondition()
        +GenerateDangerCondition()
        +GenerateRandomReading()
    }

    RegisterPage --> AuthService
    RegisterPage --> NlpApiService
    RegisterPage --> NlpAccessPolicy
    AuthService --> AppDatabase

    FaceScanPage --> FaceScanService
    FaceScanPage --> AppDatabase

    MainDashboardPage --> SensorSimulationService
    MainDashboardPage --> FuzzyRiskEngine
    MainDashboardPage --> SimpleAnnRiskEngine
    MainDashboardPage --> NlpApiService
    MainDashboardPage --> NlpAccessPolicy
    MainDashboardPage --> AppDatabase

    AiApiFacade --> FuzzyRiskEngine
    AiApiFacade --> SimpleAnnRiskEngine
    AiApiFacade --> NlpApiService

    AppDatabase --> UserAccount
    AppDatabase --> SensorReading
    AppDatabase --> RiskResult
    AppDatabase --> NlpResponse
```

## 2. Flowchart Sistem Mermaid

```mermaid
flowchart TD
    A[User membuka aplikasi] --> B[RegisterPage]
    B --> C{User memilih aksi}

    C -->|Bantuan AI / Info Mitigasi| D[NLP PUBLIC_INFO_MODE]
    D --> E[NlpApiService.GeneratePublicInfoAsync]
    E --> F[Tampilkan informasi umum mitigasi]
    F --> B

    C -->|Daftar akun| G[AuthService.RegisterAsync]
    G --> H[Simpan UserAccount ke SQLite]
    H --> I[FaceEnrollPage menyimpan template wajah]
    I --> B

    C -->|Login| J[AuthService.LoginAsync]
    J --> K{Login berhasil?}
    K -->|Tidak| B
    K -->|Ya| L[FaceScanPage]

    L --> M[FaceScanService menghitung kemiripan wajah]
    M --> N{Wajah cocok?}

    N -->|Tidak| O[Akses ditolak]
    O --> B

    N -->|Ya| P[Preferences is_face_verified = true]
    P --> Q[MainDashboardPage]

    Q --> R[Dashboard membaca data sensor simulasi]
    R --> S[SensorReading]
    S --> T[FuzzyRiskEngine.Evaluate]
    S --> U[SimpleAnnRiskEngine.PredictRisk]

    T --> V[Hitung final risk score]
    U --> V
    V --> W[RiskResult]
    W --> X[NlpApiService.ExplainRiskAsync]
    X --> Y[Tampilkan status, risk score, dan mitigasi]

    Y --> Z{Simpan data?}
    Z -->|Ya| AA[AppDatabase simpan SensorReading dan RiskResult]
    Z -->|Tidak| AB[Monitoring lanjut]
    AA --> AB

    Q --> AC{Logout?}
    AC -->|Ya| AD[Hapus session dan is_face_verified false]
    AD --> B
```

## 3. Penjelasan Singkat untuk Laporan

Sistem ini dirancang sebagai aplikasi peringatan dini potensi likuefaksi tanah berbasis .NET MAUI. Alur akses dimulai dari RegisterPage untuk registrasi dan login, kemudian dilanjutkan ke FaceScanPage sebagai gerbang keamanan sebelum pengguna masuk ke MainDashboardPage. Setelah verifikasi wajah berhasil, aplikasi menyimpan status verifikasi melalui Preferences dengan nilai is_face_verified = true.

Pada MainDashboardPage, sistem membaca data sensor simulasi yang mewakili tekanan air pori, vibrasi tanah dari sensor piezoelektrik, dan percepatan tanah. Data tersebut diproses menggunakan dua pendekatan AI internal, yaitu Fuzzy Logic dan Artificial Neural Network sederhana. Fuzzy Logic menghasilkan keputusan berdasarkan aturan Aman, Waspada, dan Bahaya, sedangkan ANN menghasilkan prediksi risk score melalui proses feed-forward dengan aktivasi sigmoid.

NLP API digunakan untuk menghasilkan penjelasan mitigasi dalam bahasa yang lebih mudah dipahami pengguna. Sebelum pengguna lolos face scan, NLP hanya bekerja pada mode PUBLIC_INFO_MODE untuk memberikan informasi umum mitigasi. Setelah pengguna berhasil login dan lolos verifikasi wajah, NLP dapat digunakan pada dashboard untuk menjelaskan hasil sensor, status risiko, dan rekomendasi mitigasi. Data pengguna, pembacaan sensor, dan hasil risiko didukung oleh SQLite melalui AppDatabase.
