# Flowchart Program LiquefactionEarlyWarning

Dokumen ini berisi flowchart utama dan flowchart per class/rutin/subrutin untuk program .NET MAUI:

**Sistem Peringatan Dini Potensi Likuefaksi Tanah Berbasis Monitoring Tekanan Air Pori dan Vibrasi Tanah Menggunakan Sensor Piezoelektrik**

---

## 1. Flowchart Sistem Utama

```mermaid
flowchart TD
    A[User membuka aplikasi] --> B[RegisterPage]
    B --> C{User memilih aksi}

    C -->|Daftar akun| D[Input username, password, role]
    D --> E[AuthService.RegisterAsync]
    E --> F{Registrasi berhasil?}
    F -->|Tidak| G[Tampilkan pesan gagal]
    G --> B
    F -->|Ya| H[Navigasi ke FaceEnrollPage]
    H --> I[Simpan template wajah]
    I --> B

    C -->|Login| J[Input username, password, role]
    J --> K[AuthService.LoginAsync]
    K --> L{Login berhasil?}
    L -->|Tidak| M[Tampilkan pesan login gagal]
    M --> B
    L -->|Ya| N[Simpan session username dan role]
    N --> O[Set is_face_verified = false]
    O --> P[FaceScanPage]

    C -->|Bantuan AI / Info Mitigasi| Q[NlpApiService.GeneratePublicInfoAsync]
    Q --> R[Tampilkan informasi umum mitigasi]
    R --> B

    P --> S[FaceScanService.CalculateSimilarity]
    S --> T{Wajah cocok?}
    T -->|Tidak| U[Akses ditolak]
    U --> B
    T -->|Ya| V[Set is_face_verified = true]
    V --> W[MainDashboardPage]

    W --> X[Cek face verification]
    X --> Y{is_face_verified true?}
    Y -->|Tidak| Z[Akses ditolak dan kembali ke RegisterPage]
    Y -->|Ya| AA[Dashboard aktif]
    AA --> AB[SensorSimulationService.GenerateRandomReading]
    AB --> AC[FuzzyRiskEngine.Evaluate]
    AB --> AD[SimpleAnnRiskEngine.PredictRisk]
    AC --> AE[Gabungkan skor Fuzzy dan ANN]
    AD --> AE
    AE --> AF[NlpApiService.ExplainRiskAsync]
    AF --> AG[Tampilkan status, risk score, dan mitigasi]
    AG --> AH{User simpan data?}
    AH -->|Ya| AI[Simpan SensorReading dan RiskResult ke SQLite]
    AH -->|Tidak| AJ[Monitoring lanjut]
    AI --> AJ
```

---

## 2. Flowchart RegisterPage

```mermaid
flowchart TD
    A[Mulai RegisterPage] --> B[Inisialisasi AppDatabase dan AuthService]
    B --> C[Set default role Petugas Lapangan]
    C --> D{User memilih tombol}

    D -->|Register| E[Ambil username, password, role]
    E --> F{Data lengkap?}
    F -->|Tidak| G[Tampilkan pesan data belum lengkap]
    F -->|Ya| H{Password minimal 4 karakter?}
    H -->|Tidak| I[Tampilkan pesan kata sandi lemah]
    H -->|Ya| J[AuthService.RegisterAsync]
    J --> K{Registrasi berhasil?}
    K -->|Tidak| L[Tampilkan pesan registrasi gagal]
    K -->|Ya| M[Tampilkan pesan berhasil]
    M --> N[ClearForm]
    N --> O[Navigasi ke FaceEnrollPage]

    D -->|Login| P[Ambil username, password, role]
    P --> Q{Data lengkap?}
    Q -->|Tidak| R[Tampilkan pesan login gagal]
    Q -->|Ya| S[AuthService.LoginAsync]
    S --> T{Login berhasil?}
    T -->|Tidak| U[Tampilkan pesan login gagal]
    T -->|Ya| V[Simpan session username dan role]
    V --> W[Set is_face_verified = false]
    W --> X[Navigasi ke FaceScanPage]

    D -->|Bantuan AI| Y[NlpAccessPolicy.CanAccessPublicInfo]
    Y --> Z{Akses public info diizinkan?}
    Z -->|Tidak| AA[Tampilkan akses ditolak]
    Z -->|Ya| AB[NlpApiService.GeneratePublicInfoAsync]
    AB --> AC[Tampilkan informasi umum mitigasi]
```

---

## 3. Flowchart FaceEnrollPage

```mermaid
flowchart TD
    A[Mulai FaceEnrollPage] --> B[Terima parameter username dan role]
    B --> C[Aktifkan kamera]
    C --> D{Kamera tersedia?}
    D -->|Tidak| E[Tampilkan kamera tidak ditemukan]
    D -->|Ya| F[User klik Simpan Template Wajah]
    F --> G[Capture frame wajah]
    G --> H{Capture berhasil?}
    H -->|Tidak| I[Tampilkan capture gagal]
    H -->|Ya| J[Ambil data UserAccount dari SQLite]
    J --> K{User ditemukan?}
    K -->|Tidak| L[Tampilkan akun tidak ditemukan]
    K -->|Ya| M[Simpan FaceImageBytes dan FaceImagePath]
    M --> N[AppDatabase.SaveUserAsync]
    N --> O[Tampilkan template wajah tersimpan]
    O --> P[Kembali ke RegisterPage]
```

---

## 4. Flowchart FaceScanPage

```mermaid
flowchart TD
    A[Mulai FaceScanPage] --> B[Set is_face_verified = false]
    B --> C[Ambil username dan role dari parameter]
    C --> D[Ambil data user dari SQLite]
    D --> E{User ditemukan?}
    E -->|Tidak| F[Akses ditolak]
    E -->|Ya| G[Load template wajah]
    G --> H{Template wajah tersedia?}
    H -->|Tidak| I[Akses ditolak]
    H -->|Ya| J[Aktifkan kamera]
    J --> K[Capture frame wajah live]
    K --> L[FaceScanService.CalculateSimilarity]
    L --> M{Similarity >= 85 persen?}
    M -->|Tidak| N[Reset success streak]
    N --> O{Timeout 15 detik?}
    O -->|Tidak| K
    O -->|Ya| P[Akses ditolak]
    M -->|Ya| Q[Tambah success streak]
    Q --> R{Success streak >= 3?}
    R -->|Tidak| K
    R -->|Ya| S[Set is_face_verified = true]
    S --> T[Navigasi ke MainDashboardPage]
```

---

## 5. Flowchart MainDashboardPage

```mermaid
flowchart TD
    A[Mulai MainDashboardPage] --> B[Cek Preferences is_face_verified dan role]
    B --> C[NlpAccessPolicy.CanAccessDashboardNlp]
    C --> D{Akses dashboard valid?}
    D -->|Tidak| E[Tampilkan akses ditolak]
    E --> F[Kembali ke RegisterPage]
    D -->|Ya| G[Dashboard siap]

    G --> H{User klik Analisis Data Simulasi?}
    H -->|Ya| I[SensorSimulationService.GenerateRandomReading]
    I --> J[FuzzyRiskEngine.Evaluate]
    I --> K[SimpleAnnRiskEngine.PredictRisk]
    J --> L[Hitung final risk score]
    K --> L
    L --> M[Tentukan status Aman/Waspada/Bahaya]
    M --> N[NlpApiService.ExplainRiskAsync]
    N --> O[Tampilkan tekanan, vibrasi, acceleration, score, status, mitigasi]

    O --> P{User klik Simpan Data?}
    P -->|Ya| Q[AppDatabase.SaveSensorReadingAsync]
    Q --> R[AppDatabase.SaveRiskResultAsync]
    R --> S[Tampilkan data berhasil disimpan]
    P -->|Tidak| T[Monitoring lanjut]

    G --> U{User klik Logout?}
    U -->|Ya| V[Hapus session username dan role]
    V --> W[Set is_face_verified = false]
    W --> X[Kembali ke RegisterPage]
```

---

## 6. Flowchart AuthService

```mermaid
flowchart TD
    A[Mulai AuthService] --> B{Method dipanggil}

    B -->|RegisterAsync| C[Terima username, password, role]
    C --> D[Cek username di database]
    D --> E{Username sudah ada?}
    E -->|Ya| F[Return gagal: username terdaftar]
    E -->|Tidak| G[Hash password]
    G --> H[Buat UserAccount]
    H --> I[AppDatabase.SaveUserAsync]
    I --> J[Return sukses]

    B -->|LoginAsync| K[Terima username, password, role]
    K --> L[Ambil user dari database]
    L --> M{User ditemukan?}
    M -->|Tidak| N[Return gagal]
    M -->|Ya| O[Hash password input]
    O --> P{Password cocok?}
    P -->|Tidak| Q[Return gagal]
    P -->|Ya| R{Role cocok?}
    R -->|Tidak| S[Return gagal]
    R -->|Ya| T[Return sukses dengan UserAccount]
```

---

## 7. Flowchart FaceScanService

```mermaid
flowchart TD
    A[Mulai CalculateSimilarity] --> B[Terima templateBytes dan liveFrame]
    B --> C[Decode gambar template]
    C --> D[Decode gambar live]
    D --> E{Gambar valid?}
    E -->|Tidak| F[Return similarity 0]
    E -->|Ya| G[Resize gambar ke ukuran kecil]
    G --> H[Konversi piksel ke grayscale]
    H --> I[Hitung selisih nilai piksel]
    I --> J[Hitung rata-rata perbedaan]
    J --> K[Konversi menjadi similarity persen]
    K --> L[Return similarity]
```

---

## 8. Flowchart NlpApiService

```mermaid
flowchart TD
    A[Mulai NlpApiService] --> B{Method dipanggil}

    B -->|GeneratePublicInfoAsync| C[Terima pertanyaan publik]
    C --> D[CheckBypassIntentAsync]
    D --> E{Ada indikasi bypass?}
    E -->|Ya| F[Return safe response public info]
    E -->|Tidak| G[Buat prompt PUBLIC_INFO_MODE]
    G --> H[AskAsync]

    B -->|GenerateMitigationTextAsync| I[Terima RiskResult dan SensorReading]
    I --> J[Buat prompt SECURE_DASHBOARD_ASSISTANT]
    J --> H

    B -->|ExplainRiskAsync| K[Terima status, score, pressure, vibration, acceleration]
    K --> L[Buat prompt penjelasan risiko]
    L --> H

    H --> M{API key dan model sudah diisi?}
    M -->|Tidak| N[Return fallback lokal]
    M -->|Ya| O[Kirim request HttpClient ke API NLP eksternal]
    O --> P{Response sukses?}
    P -->|Tidak| Q[Return fallback lokal]
    P -->|Ya| R[Ekstrak content jawaban]
    R --> S[Return jawaban NLP]
```

---

## 9. Flowchart NlpAccessPolicy

```mermaid
flowchart TD
    A[Mulai NlpAccessPolicy] --> B{Cek mode akses}

    B -->|CanAccessPublicInfo| C[Return true]

    B -->|CanAccessDashboardNlp| D[Cek isFaceVerified]
    D --> E{isFaceVerified true?}
    E -->|Tidak| F[Return false]
    E -->|Ya| G[Cek role]
    G --> H{Role valid?}
    H -->|Tidak| I[Return false]
    H -->|Ya| J[Return true]

    B -->|GetNlpMode| K{Face verified?}
    K -->|Tidak| L[PUBLIC_INFO_MODE]
    K -->|Ya| M[SECURE_DASHBOARD_ASSISTANT]
```

---

## 10. Flowchart FuzzyRiskEngine

```mermaid
flowchart TD
    A[Input pressure, vibration, acceleration] --> B[Hitung pressureLow, pressureMedium, pressureHigh]
    B --> C[Hitung vibrationLow, vibrationMedium, vibrationHigh]
    C --> D[Hitung accelerationHigh]
    D --> E[Terapkan aturan fuzzy]

    E --> F[Rule Aman: tekanan rendah + vibrasi rendah]
    E --> G[Rule Waspada: tekanan sedang + vibrasi sedang]
    E --> H[Rule Waspada: tekanan tinggi + vibrasi sedang]
    E --> I[Rule Bahaya: tekanan tinggi + vibrasi tinggi]
    E --> J[Rule Bahaya: acceleration tinggi + tekanan naik]

    F --> K[Gabungkan kekuatan rule]
    G --> K
    H --> K
    I --> K
    J --> K

    K --> L[Defuzzifikasi dengan bobot Aman 20, Waspada 55, Bahaya 90]
    L --> M[Hitung RiskScore 0 sampai 100]
    M --> N{RiskScore}
    N -->|Kurang dari 40| O[Status Aman]
    N -->|40 sampai 69| P[Status Waspada]
    N -->|70 ke atas| Q[Status Bahaya]
    O --> R[Return FuzzyRiskResult]
    P --> R
    Q --> R
```

---

## 11. Flowchart SimpleAnnRiskEngine

```mermaid
flowchart TD
    A[Mulai ANN] --> B{Method dipanggil}

    B -->|Train| C[Ambil dataset training]
    C --> D[Loop epoch]
    D --> E[TrainOneSample]
    E --> F[Forward pass]
    F --> G[Hitung error]
    G --> H[Backpropagation]
    H --> I[Update bobot dan bias]
    I --> J{Epoch selesai?}
    J -->|Tidak| D
    J -->|Ya| K[Set isTrained true]

    B -->|PredictRisk| L{Sudah training?}
    L -->|Tidak| C
    L -->|Ya| M[FeedForward]
    M --> N[Normalisasi input pressure, vibration, acceleration]
    N --> O[Hitung 4 hidden neuron]
    O --> P[Aktivasi sigmoid hidden layer]
    P --> Q[Hitung output neuron]
    Q --> R[Aktivasi sigmoid output]
    R --> S[Konversi output ke RiskScore 0 sampai 100]
    S --> T{RiskScore}
    T -->|Kurang dari 40| U[Status Aman]
    T -->|40 sampai 69| V[Status Waspada]
    T -->|70 ke atas| W[Status Bahaya]
    U --> X[Return AnnRiskResult]
    V --> X
    W --> X
```

---

## 12. Flowchart AiApiFacade

```mermaid
flowchart TD
    A[Mulai AiApiFacade] --> B{Method dipanggil}

    B -->|AnalyzeWithFuzzyAsync| C[Terima SensorReading]
    C --> D[FuzzyRiskEngine.Evaluate]
    D --> E[Return FuzzyRiskResult]

    B -->|AnalyzeWithAnnAsync| F[Terima SensorReading]
    F --> G[SimpleAnnRiskEngine.PredictRisk]
    G --> H[Return AnnRiskResult]

    B -->|AskNlpAsync| I[Terima prompt]
    I --> J[NlpApiService.AskAsync]
    J --> K[Return jawaban NLP]

    B -->|GenerateFinalDecisionAsync| L[Terima SensorReading]
    L --> M[AnalyzeWithFuzzyAsync]
    L --> N[AnalyzeWithAnnAsync]
    M --> O[Gabungkan skor Fuzzy dan ANN]
    N --> O
    O --> P[Tentukan final status]
    P --> Q[Buat RiskResult]
    Q --> R[NlpApiService.GenerateMitigationTextAsync]
    R --> S[Return AiFinalDecision]
```

---

## 13. Flowchart AppDatabase

```mermaid
flowchart TD
    A[Mulai AppDatabase] --> B[Inisialisasi SQLiteAsyncConnection]
    B --> C[CreateTable UserAccount]
    C --> D[CreateTable SensorReading]
    D --> E[CreateTable RiskResult]
    E --> F[CreateTable NlpResponse]

    F --> G{Method database dipanggil}

    G -->|SaveUserAsync| H[Insert atau Update UserAccount]
    G -->|GetUserByUsernameAsync| I[Query user berdasarkan username]
    G -->|SaveSensorReadingAsync| J[Insert SensorReading]
    G -->|SaveRiskResultAsync| K[Insert RiskResult]
    G -->|SaveNlpResponseAsync| L[Insert NlpResponse]

    H --> M[Return hasil]
    I --> M
    J --> M
    K --> M
    L --> M
```

---

## 14. Flowchart SensorSimulationService

```mermaid
flowchart TD
    A[Mulai SensorSimulationService] --> B{Jenis data simulasi}

    B -->|GenerateNormalCondition| C[Buat tekanan rendah, vibrasi rendah, acceleration rendah]
    C --> D[Return SensorReading Aman]

    B -->|GenerateWarningCondition| E[Buat tekanan sedang, vibrasi sedang, acceleration sedang]
    E --> F[Return SensorReading Waspada]

    B -->|GenerateDangerCondition| G[Buat tekanan tinggi, vibrasi tinggi, acceleration tinggi]
    G --> H[Return SensorReading Bahaya]

    B -->|GenerateRandomReading| I[Pilih kondisi secara acak]
    I --> J{Kondisi terpilih}
    J -->|Normal| C
    J -->|Warning| E
    J -->|Danger| G
```

---

## 15. Ringkasan

Flowchart ini menunjukkan bahwa sistem memiliki alur utama sebagai berikut:

1. Pengguna melakukan registrasi atau login.
2. Pengguna yang login harus melewati verifikasi wajah.
3. Dashboard hanya dapat dibuka jika `is_face_verified = true`.
4. Dashboard membaca data sensor simulasi.
5. Data sensor dianalisis oleh Fuzzy Logic dan ANN.
6. Hasil AI dijelaskan oleh NLP API.
7. Data sensor dan hasil risiko disimpan ke SQLite.
