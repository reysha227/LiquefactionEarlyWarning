﻿using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;
using SkiaSharp.Views.Maui.Controls.Hosting;
using SQLitePCL;

namespace LiquefactionEarlyWarning;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        // Inisialisasi SQLite native provider.
        // Penting agar SQLite aman dipakai di Windows Machine.
        Batteries_V2.Init();

        var builder = MauiApp.CreateBuilder();

        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .UseMauiCommunityToolkitCamera()
            .UseSkiaSharp()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

        // Database lokal
        builder.Services.AddSingleton<AppDatabase>();

        // Untuk API NLP nanti:
        // Gemini / DeepSeek / ChatGPT dapat memakai HttpClient.
        builder.Services.AddSingleton<HttpClient>();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}