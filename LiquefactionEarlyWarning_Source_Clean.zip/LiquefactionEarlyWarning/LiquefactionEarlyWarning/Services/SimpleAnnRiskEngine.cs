﻿namespace LiquefactionEarlyWarning.Services;

public class SimpleAnnRiskEngine
{
    private readonly Random _random = new(7);

    private readonly double[,] _inputHiddenWeights = new double[3, 4];
    private readonly double[] _hiddenBias = new double[4];

    private readonly double[] _hiddenOutputWeights = new double[4];
    private double _outputBias;

    private bool _isTrained;

    public SimpleAnnRiskEngine()
    {
        InitializeWeights();
    }

    public double FeedForward(double pressure, double vibration, double acceleration)
    {
        double[] inputs = NormalizeInputs(pressure, vibration, acceleration);

        double[] hidden = new double[4];

        for (int h = 0; h < 4; h++)
        {
            double sum = _hiddenBias[h];

            for (int i = 0; i < 3; i++)
            {
                sum += inputs[i] * _inputHiddenWeights[i, h];
            }

            hidden[h] = Sigmoid(sum);
        }

        double outputSum = _outputBias;

        for (int h = 0; h < 4; h++)
        {
            outputSum += hidden[h] * _hiddenOutputWeights[h];
        }

        return Sigmoid(outputSum);
    }

    public void Train()
    {
        int epochs = 3000;
        double learningRate = 0.35;

        List<AnnTrainingSample> dataset = CreateDataset();

        for (int epoch = 0; epoch < epochs; epoch++)
        {
            foreach (AnnTrainingSample sample in dataset)
            {
                TrainOneSample(sample, learningRate);
            }
        }

        _isTrained = true;
    }

    public AnnRiskResult PredictRisk(double pressure, double vibration, double acceleration)
    {
        if (!_isTrained)
        {
            Train();
        }

        double output = FeedForward(pressure, vibration, acceleration);

        double riskScore = Math.Round(Math.Clamp(output * 100.0, 0, 100), 2);

        string status = GetStatusFromScore(riskScore);

        return new AnnRiskResult
        {
            RiskScore = riskScore,
            Status = status,
            RawOutput = Math.Round(output, 4)
        };
    }

    private void TrainOneSample(AnnTrainingSample sample, double learningRate)
    {
        double[] inputs = NormalizeInputs(
            sample.Pressure,
            sample.Vibration,
            sample.Acceleration);

        double[] hidden = new double[4];

        for (int h = 0; h < 4; h++)
        {
            double sum = _hiddenBias[h];

            for (int i = 0; i < 3; i++)
            {
                sum += inputs[i] * _inputHiddenWeights[i, h];
            }

            hidden[h] = Sigmoid(sum);
        }

        double outputSum = _outputBias;

        for (int h = 0; h < 4; h++)
        {
            outputSum += hidden[h] * _hiddenOutputWeights[h];
        }

        double output = Sigmoid(outputSum);

        double error = sample.Target - output;
        double outputDelta = error * SigmoidDerivative(output);

        for (int h = 0; h < 4; h++)
        {
            _hiddenOutputWeights[h] += learningRate * outputDelta * hidden[h];
        }

        _outputBias += learningRate * outputDelta;

        for (int h = 0; h < 4; h++)
        {
            double hiddenError = outputDelta * _hiddenOutputWeights[h];
            double hiddenDelta = hiddenError * SigmoidDerivative(hidden[h]);

            for (int i = 0; i < 3; i++)
            {
                _inputHiddenWeights[i, h] += learningRate * hiddenDelta * inputs[i];
            }

            _hiddenBias[h] += learningRate * hiddenDelta;
        }
    }

    private List<AnnTrainingSample> CreateDataset()
    {
        return new List<AnnTrainingSample>
        {
            new AnnTrainingSample(15, 0.10, 0.03, 0.10),
            new AnnTrainingSample(25, 0.20, 0.06, 0.18),
            new AnnTrainingSample(35, 0.25, 0.08, 0.28),

            new AnnTrainingSample(45, 0.40, 0.12, 0.50),
            new AnnTrainingSample(60, 0.55, 0.18, 0.60),
            new AnnTrainingSample(70, 0.65, 0.20, 0.68),

            new AnnTrainingSample(80, 0.80, 0.24, 0.82),
            new AnnTrainingSample(95, 1.00, 0.32, 0.92),
            new AnnTrainingSample(115, 1.20, 0.42, 0.98)
        };
    }

    private double[] NormalizeInputs(double pressure, double vibration, double acceleration)
    {
        return new[]
        {
            Math.Clamp(pressure / 120.0, 0, 1),
            Math.Clamp(vibration / 1.20, 0, 1),
            Math.Clamp(acceleration / 0.45, 0, 1)
        };
    }

    private void InitializeWeights()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int h = 0; h < 4; h++)
            {
                _inputHiddenWeights[i, h] = RandomWeight();
            }
        }

        for (int h = 0; h < 4; h++)
        {
            _hiddenBias[h] = RandomWeight();
            _hiddenOutputWeights[h] = RandomWeight();
        }

        _outputBias = RandomWeight();
    }

    private double RandomWeight()
    {
        return (_random.NextDouble() * 2.0 - 1.0) * 0.5;
    }

    private static double Sigmoid(double x)
    {
        return 1.0 / (1.0 + Math.Exp(-x));
    }

    private static double SigmoidDerivative(double output)
    {
        return output * (1.0 - output);
    }

    private static string GetStatusFromScore(double score)
    {
        if (score < 40)
            return "Aman";

        if (score < 70)
            return "Waspada";

        return "Bahaya";
    }
}

public class AnnTrainingSample
{
    public double Pressure { get; }
    public double Vibration { get; }
    public double Acceleration { get; }
    public double Target { get; }

    public AnnTrainingSample(
        double pressure,
        double vibration,
        double acceleration,
        double target)
    {
        Pressure = pressure;
        Vibration = vibration;
        Acceleration = acceleration;
        Target = target;
    }
}

public class AnnRiskResult
{
    public double RiskScore { get; set; }

    public string Status { get; set; } = "Aman";

    public double RawOutput { get; set; }
}