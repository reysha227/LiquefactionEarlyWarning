﻿using System.Security.Cryptography;
using System.Text;
using LiquefactionEarlyWarning;

namespace LiquefactionEarlyWarning.Services;

public class AuthService
{
    private readonly AppDatabase _database;

    public AuthService(AppDatabase database)
    {
        _database = database;
    }

    public async Task<(bool Success, string Message)> RegisterAsync(
        string username,
        string password,
        string role)
    {
        try
        {
            username = username.Trim();

            UserAccount? existingUser = await _database.GetUserByUsernameAsync(username);

            if (existingUser != null)
            {
                return (false, "Nama pengguna sudah terdaftar. Gunakan nama lain.");
            }

            UserAccount newUser = new()
            {
                Username = username,
                PasswordHash = HashPassword(password),
                FullName = username,
                Role = role,
                FaceImagePath = string.Empty,
                FaceImageBytes = null,
                IsActive = true,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            await _database.SaveUserAsync(newUser);

            return (true, "Registrasi berhasil.");
        }
        catch (Exception ex)
        {
            return (false, $"Registrasi gagal: {ex.Message}");
        }
    }

    public async Task<(bool Success, string Message, UserAccount? User)> LoginAsync(
        string username,
        string password,
        string selectedRole)
    {
        try
        {
            username = username.Trim();

            UserAccount? user = await _database.GetUserByUsernameAsync(username);

            if (user == null)
            {
                return (false, "Nama pengguna tidak ditemukan.", null);
            }

            if (!user.IsActive)
            {
                return (false, "Akun ini sedang tidak aktif.", null);
            }

            string passwordHash = HashPassword(password);

            if (user.PasswordHash != passwordHash)
            {
                return (false, "Kata sandi salah.", null);
            }

            if (!string.Equals(user.Role, selectedRole, StringComparison.OrdinalIgnoreCase))
            {
                return (
                    false,
                    $"Role tidak sesuai. Akun ini terdaftar sebagai {user.Role}.",
                    null);
            }

            return (true, "Login berhasil.", user);
        }
        catch (Exception ex)
        {
            return (false, $"Login gagal: {ex.Message}", null);
        }
    }

    private static string HashPassword(string password)
    {
        byte[] inputBytes = Encoding.UTF8.GetBytes(password);
        byte[] hashBytes = SHA256.HashData(inputBytes);

        StringBuilder builder = new();

        foreach (byte b in hashBytes)
        {
            builder.Append(b.ToString("x2"));
        }

        return builder.ToString();
    }
}