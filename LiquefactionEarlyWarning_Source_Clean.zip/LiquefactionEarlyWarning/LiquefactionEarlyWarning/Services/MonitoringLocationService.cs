﻿namespace LiquefactionEarlyWarning.Services;

public class MonitoringLocationService
{
    private readonly Random _random = new();

    private readonly List<MonitoringLocationData> _locations = new()
    {
        new MonitoringLocationData
        {
            Id = 1,
            Code = "A",
            Name = "Zona A - Pesisir Jenuh Air",
            Coordinate = "-0.9081, 119.8702",
            AreaType = "Pesisir / tanah jenuh air",
            Description = "Titik monitoring dekat pesisir dengan potensi peningkatan tekanan air pori saat terjadi getaran tanah.",
            BasePressure = 68,
            BaseVibration = 0.56,
            BaseAcceleration = 0.16
        },
        new MonitoringLocationData
        {
            Id = 2,
            Code = "B",
            Name = "Zona B - Permukiman Padat",
            Coordinate = "-0.9024, 119.8629",
            AreaType = "Permukiman warga",
            Description = "Area permukiman yang perlu dipantau karena berada pada lapisan tanah lunak dan dekat bangunan warga.",
            BasePressure = 42,
            BaseVibration = 0.31,
            BaseAcceleration = 0.09
        },
        new MonitoringLocationData
        {
            Id = 3,
            Code = "C",
            Name = "Zona C - Bantaran Sungai",
            Coordinate = "-0.8950, 119.8585",
            AreaType = "Bantaran sungai",
            Description = "Area dekat aliran sungai dengan kadar air tanah tinggi sehingga perlu pemantauan tekanan air pori.",
            BasePressure = 78,
            BaseVibration = 0.72,
            BaseAcceleration = 0.24
        },
        new MonitoringLocationData
        {
            Id = 4,
            Code = "D",
            Name = "Zona D - Infrastruktur Jalan",
            Coordinate = "-0.8893, 119.8735",
            AreaType = "Jalan dan fasilitas umum",
            Description = "Area jalan dan fasilitas publik yang dipantau untuk mengurangi risiko kerusakan akibat tanah ambles.",
            BasePressure = 55,
            BaseVibration = 0.43,
            BaseAcceleration = 0.13
        }
    };

    private int _activeIndex;

    public MonitoringLocationData GetActiveLocation()
    {
        return _locations[_activeIndex];
    }

    public IReadOnlyList<MonitoringLocationData> GetAllLocations()
    {
        return _locations;
    }

    public MonitoringLocationData MoveNextLocation()
    {
        _activeIndex++;

        if (_activeIndex >= _locations.Count)
            _activeIndex = 0;

        return GetActiveLocation();
    }

    public SensorReading GenerateReadingForLocation(MonitoringLocationData location)
    {
        double pressure = location.BasePressure + RandomRange(-8, 12);
        double vibration = location.BaseVibration + RandomRange(-0.12, 0.18);
        double acceleration = location.BaseAcceleration + RandomRange(-0.04, 0.06);

        pressure = Math.Clamp(pressure, 5, 120);
        vibration = Math.Clamp(vibration, 0.01, 1.30);
        acceleration = Math.Clamp(acceleration, 0.01, 0.45);

        return new SensorReading
        {
            Timestamp = DateTime.Now,
            PoreWaterPressureKPa = Math.Round(pressure, 2),
            VibrationAmplitude = Math.Round(vibration, 3),
            GroundAccelerationG = Math.Round(acceleration, 3),
            Source = location.Name,
            Notes = $"Data monitoring simulasi untuk {location.Name} ({location.Coordinate})."
        };
    }

    private double RandomRange(double min, double max)
    {
        return min + (_random.NextDouble() * (max - min));
    }
}

public class MonitoringLocationData
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Coordinate { get; set; } = string.Empty;
    public string AreaType { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public double BasePressure { get; set; }
    public double BaseVibration { get; set; }
    public double BaseAcceleration { get; set; }
}
