﻿namespace LiquefactionEarlyWarning.Services;

public enum NlpMode
{
    PUBLIC_INFO_MODE,
    SECURE_DASHBOARD_ASSISTANT
}

public class NlpAccessPolicy
{
    public bool CanAccessPublicInfo(bool isLoggedIn)
    {
        // Informasi publik boleh dibuka sebelum atau sesudah login.
        // Tetapi hanya untuk edukasi umum mitigasi, bukan akses dashboard.
        return true;
    }

    public bool CanAccessDashboardNlp(bool isFaceVerified, string role)
    {
        if (!isFaceVerified)
            return false;

        if (string.IsNullOrWhiteSpace(role))
            return false;

        return role == "Petugas Lapangan" || role == "Warga Sipil";
    }

    public NlpMode GetNlpMode(bool isFaceVerified)
    {
        if (isFaceVerified)
            return NlpMode.SECURE_DASHBOARD_ASSISTANT;

        return NlpMode.PUBLIC_INFO_MODE;
    }
}