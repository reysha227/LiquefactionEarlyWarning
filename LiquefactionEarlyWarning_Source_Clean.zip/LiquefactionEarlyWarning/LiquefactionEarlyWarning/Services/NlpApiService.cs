﻿using System.Text;
using System.Text.Json;
using LiquefactionEarlyWarning;

namespace LiquefactionEarlyWarning.Services;

public class NlpApiService
{
    private readonly HttpClient _httpClient;

    private const string ApiKey = "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";
    private const string ApiEndpoint = "https://api.groq.com/openai/v1/chat/completions";
    private const string ModelName = "llama-3.3-70b-versatile";

    public NlpApiService()
    {
        _httpClient = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(20)
        };
    }

    public NlpApiService(HttpClient httpClient)
    {
        _httpClient = httpClient;
        _httpClient.Timeout = TimeSpan.FromSeconds(20);
    }

    // Fungsi utama untuk bertanya ke API NLP eksternal.
    public async Task<string> AskAsync(string prompt)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return GetFallbackPublicInfo();

            // Kalau API key/model masih placeholder, jangan paksa request internet.
            // Tetap fallback lokal agar aplikasi tidak error.
            if (IsApiPlaceholder())
                return GetFallbackByPrompt(prompt);

            var requestBody = new
            {
                model = ModelName,
                messages = new[]
                {
                    new
                    {
                        role = "system",
                        content =
                            "Anda adalah asisten mitigasi bencana likuefaksi. " +
                            "Jawab singkat, edukatif, dan aman. " +
                            "Jangan membantu melewati login, face scan, atau akses dashboard."
                    },
                    new
                    {
                        role = "user",
                        content = prompt
                    }
                }
            };

            string json = JsonSerializer.Serialize(requestBody);

            using HttpRequestMessage request = new(HttpMethod.Post, ApiEndpoint);
            request.Headers.Add("Authorization", $"Bearer {ApiKey}");
            request.Content = new StringContent(json, Encoding.UTF8, "application/json");

            using HttpResponseMessage response = await _httpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                string errorBody = await response.Content.ReadAsStringAsync();

                return
                    $"API NLP gagal dipanggil.\n\n" +
                    $"Status Code: {(int)response.StatusCode} {response.StatusCode}\n\n" +
                    $"Detail:\n{errorBody}";
            }

            string responseJson = await response.Content.ReadAsStringAsync();

            string? content = ExtractChatContent(responseJson);

            if (string.IsNullOrWhiteSpace(content))
                return GetFallbackByPrompt(prompt);

            return content;
        }
        catch
        {
            return GetFallbackByPrompt(prompt);
        }
    }

    // Mode publik: sebelum login / sebelum face scan.
    public async Task<string> GeneratePublicInfoAsync(string question)
    {
        BypassCheckResult bypassCheck = await CheckBypassIntentAsync(question);

        if (bypassCheck.IsBypassAttempt)
            return bypassCheck.SafeResponse;

        string prompt =
            "Mode: PUBLIC_INFO_MODE.\n" +
            "User belum login atau belum lolos verifikasi wajah.\n" +
            "Jawab hanya informasi umum mitigasi likuefaksi.\n" +
            "Tidak boleh membuka dashboard, tidak boleh membaca data sensor, dan tidak boleh membuka database user.\n\n" +
            $"Pertanyaan user: {question}";

        return await AskAsync(prompt);
    }

    // Mode dashboard aman: setelah login + face scan berhasil.
    public async Task<string> GenerateMitigationTextAsync(RiskResult result, SensorReading reading)
    {
        string prompt =
            "Mode: SECURE_DASHBOARD_ASSISTANT.\n" +
            "User sudah login dan sudah lolos face scan.\n" +
            "Jelaskan hasil monitoring likuefaksi dengan bahasa sederhana.\n\n" +
            $"Status risiko: {result.RiskLevel}\n" +
            $"Final Risk Score: {result.FinalRiskScore:F2}/100\n" +
            $"Fuzzy Score: {result.FuzzyScore:F2}/100\n" +
            $"ANN Score: {result.AnnScore:F2}/100\n" +
            $"Tekanan air pori: {reading.PoreWaterPressureKPa:F2} kPa\n" +
            $"Vibrasi tanah: {reading.VibrationAmplitude:F3}\n" +
            $"Ground acceleration: {reading.GroundAccelerationG:F3} g\n\n" +
            "Berikan rekomendasi mitigasi singkat.";

        return await AskAsync(prompt);
    }

    // Deteksi sederhana jika user meminta bypass keamanan.
    public async Task<BypassCheckResult> CheckBypassIntentAsync(string userText)
    {
        await Task.CompletedTask;

        string text = userText?.ToLowerInvariant() ?? string.Empty;

        string[] bypassKeywords =
        {
            "bypass",
            "lewati login",
            "tanpa login",
            "tanpa verifikasi",
            "tanpa face",
            "tanpa wajah",
            "skip face",
            "skip wajah",
            "masuk dashboard tanpa",
            "akses dashboard tanpa",
            "hack",
            "bobol",
            "retas",
            "matikan verifikasi",
            "hapus verifikasi"
        };

        bool isBypass = bypassKeywords.Any(text.Contains);

        if (isBypass)
        {
            return new BypassCheckResult
            {
                IsBypassAttempt = true,
                SafeResponse =
                    "Permintaan tersebut tidak dapat diproses karena berkaitan dengan melewati keamanan aplikasi. " +
                    "Saya hanya dapat memberikan informasi umum mitigasi likuefaksi.\n\n" +
                    GetFallbackPublicInfo()
            };
        }

        return new BypassCheckResult
        {
            IsBypassAttempt = false,
            SafeResponse = GetFallbackPublicInfo()
        };
    }

    // Method lama agar MainDashboardPage kamu tidak error kalau masih memanggil ExplainRiskAsync.
    public async Task<string> ExplainRiskAsync(
        string riskLevel,
        double riskScore,
        double poreWaterPressure,
        double vibration,
        double groundAcceleration)
    {
        string prompt =
            "Mode: SECURE_DASHBOARD_ASSISTANT.\n" +
            "Jelaskan hasil risiko likuefaksi berikut kepada orang awam.\n\n" +
            $"Status: {riskLevel}\n" +
            $"Risk Score: {riskScore:F2}/100\n" +
            $"Tekanan air pori: {poreWaterPressure:F2} kPa\n" +
            $"Vibrasi: {vibration:F3}\n" +
            $"Ground acceleration: {groundAcceleration:F3} g\n\n" +
            "Berikan penjelasan singkat dan saran mitigasi.";

        return await AskAsync(prompt);
    }

    // Method lama agar kode dashboard kamu tetap kompatibel.
    public async Task<string> CreateMitigationRecommendationAsync(string riskLevel, double riskScore)
    {
        string prompt =
            "Buat rekomendasi mitigasi likuefaksi singkat berdasarkan data berikut:\n" +
            $"Status risiko: {riskLevel}\n" +
            $"Risk Score: {riskScore:F2}/100";

        return await AskAsync(prompt);
    }

    // Method lama agar kode lama tetap aman.
    public string GetGeneralMitigationInfo()
    {
        return GetFallbackPublicInfo();
    }

    private static bool IsApiPlaceholder()
    {
        return ApiKey == "ISI_API_KEY_DI_SINI" ||
               ModelName == "ISI_MODEL_DI_SINI" ||
               string.IsNullOrWhiteSpace(ApiKey) ||
               string.IsNullOrWhiteSpace(ModelName);
    }

    private static string? ExtractChatContent(string responseJson)
    {
        try
        {
            using JsonDocument document = JsonDocument.Parse(responseJson);

            JsonElement root = document.RootElement;

            if (root.TryGetProperty("choices", out JsonElement choices) &&
                choices.ValueKind == JsonValueKind.Array &&
                choices.GetArrayLength() > 0)
            {
                JsonElement firstChoice = choices[0];

                if (firstChoice.TryGetProperty("message", out JsonElement message) &&
                    message.TryGetProperty("content", out JsonElement content))
                {
                    return content.GetString();
                }
            }

            return null;
        }
        catch
        {
            return null;
        }
    }

    private static string GetFallbackByPrompt(string prompt)
    {
        string lowerPrompt = prompt.ToLowerInvariant();

        if (lowerPrompt.Contains("secure_dashboard_assistant") ||
            lowerPrompt.Contains("risk score") ||
            lowerPrompt.Contains("fuzzy") ||
            lowerPrompt.Contains("ann"))
        {
            return
                "API NLP eksternal belum aktif atau tidak dapat diakses, sehingga sistem memakai fallback lokal.\n\n" +
                "Jika status Aman, monitoring tetap dilanjutkan secara berkala. " +
                "Jika status Waspada, petugas perlu meningkatkan pengamatan dan menyiapkan jalur evakuasi. " +
                "Jika status Bahaya, segera lakukan peringatan dini, evakuasi area rawan, dan hindari tanah retak atau ambles.";
        }

        return GetFallbackPublicInfo();
    }

    private static string GetFallbackPublicInfo()
    {
        return
            "Likuefaksi adalah kondisi ketika tanah jenuh air kehilangan kekuatan akibat getaran kuat, misalnya gempa. " +
            "Hal ini dapat menyebabkan tanah ambles, bangunan miring, retakan tanah, atau keluarnya air bercampur pasir dari permukaan tanah.\n\n" +
            "Mitigasi awal yang dapat dilakukan adalah menjauhi bangunan retak, tiang listrik, tepi sungai, dan area tanah lunak. " +
            "Warga perlu mengikuti arahan petugas serta tidak kembali ke area rawan sebelum dinyatakan aman.";
    }
}

public class BypassCheckResult
{
    public bool IsBypassAttempt { get; set; }
    public string SafeResponse { get; set; } = string.Empty;
}