﻿using SkiaSharp;

namespace LiquefactionEarlyWarning.Services;

public class FaceScanService
{
    private const int FeatureWidth = 32;
    private const int FeatureHeight = 32;
    private const int FeatureLength = FeatureWidth * FeatureHeight;

    /*
     * Catatan penting:
     * Ini adalah simulasi praktikum pengolahan citra piksel.
     * Metode ini BUKAN face recognition biometrik komersial.
     *
     * Metode:
     * 1. Decode citra.
     * 2. Resize ke 32x32 piksel.
     * 3. Ubah RGB menjadi grayscale.
     * 4. Bandingkan selisih grayscale tiap piksel.
     * 5. Hitung similarity 0-100%.
     */

    public double CalculateSimilarity(byte[] templateImageBytes, Stream liveImageStream)
    {
        if (templateImageBytes == null || templateImageBytes.Length == 0)
            return 0;

        if (liveImageStream == null)
            return 0;

        byte[] templateFeatures = ExtractFeatureVector(templateImageBytes);
        byte[] liveFeatures = ExtractFeatureVector(liveImageStream);

        return CompareFeatureVectors(templateFeatures, liveFeatures);
    }

    public double CalculateSimilarity(byte[] templateImageBytes, byte[] liveImageBytes)
    {
        if (templateImageBytes == null || templateImageBytes.Length == 0)
            return 0;

        if (liveImageBytes == null || liveImageBytes.Length == 0)
            return 0;

        byte[] templateFeatures = ExtractFeatureVector(templateImageBytes);
        byte[] liveFeatures = ExtractFeatureVector(liveImageBytes);

        return CompareFeatureVectors(templateFeatures, liveFeatures);
    }

    private byte[] ExtractFeatureVector(byte[] imageBytes)
    {
        using MemoryStream stream = new(imageBytes);
        return ExtractFeatureVector(stream);
    }

    private byte[] ExtractFeatureVector(Stream imageStream)
    {
        if (imageStream.CanSeek)
            imageStream.Position = 0;

        using SKBitmap? originalBitmap = SKBitmap.Decode(imageStream);

        if (originalBitmap == null)
            return new byte[FeatureLength];

        SKImageInfo targetInfo = new(FeatureWidth, FeatureHeight);

        using SKBitmap resizedBitmap =
            originalBitmap.Resize(targetInfo, SKFilterQuality.Medium)
            ?? CreateEmptyBitmap();

        byte[] features = new byte[FeatureLength];

        int index = 0;

        for (int y = 0; y < FeatureHeight; y++)
        {
            for (int x = 0; x < FeatureWidth; x++)
            {
                SKColor pixel = resizedBitmap.GetPixel(x, y);

                byte gray = ConvertToGrayscale(pixel);
                features[index] = gray;

                index++;
            }
        }

        return features;
    }

    private double CompareFeatureVectors(byte[] templateFeatures, byte[] liveFeatures)
    {
        if (templateFeatures.Length != FeatureLength || liveFeatures.Length != FeatureLength)
            return 0;

        double totalDifference = 0;

        for (int i = 0; i < FeatureLength; i++)
        {
            totalDifference += Math.Abs(templateFeatures[i] - liveFeatures[i]);
        }

        double averageDifference = totalDifference / FeatureLength;

        double similarity = 100.0 - ((averageDifference / 255.0) * 100.0);

        if (similarity < 0)
            similarity = 0;

        if (similarity > 100)
            similarity = 100;

        return similarity;
    }

    private static byte ConvertToGrayscale(SKColor color)
    {
        double gray =
            (0.299 * color.Red) +
            (0.587 * color.Green) +
            (0.114 * color.Blue);

        return (byte)Math.Clamp(gray, 0, 255);
    }

    private static SKBitmap CreateEmptyBitmap()
    {
        SKBitmap bitmap = new(FeatureWidth, FeatureHeight);

        using SKCanvas canvas = new(bitmap);
        canvas.Clear(SKColors.Black);

        return bitmap;
    }
}