﻿using LiquefactionEarlyWarning;

namespace LiquefactionEarlyWarning.Services;

public class AiApiFacade
{
    private readonly FuzzyRiskEngine _fuzzyRiskEngine;
    private readonly SimpleAnnRiskEngine _annRiskEngine;
    private readonly NlpApiService _nlpApiService;

    public AiApiFacade()
    {
        _fuzzyRiskEngine = new FuzzyRiskEngine();
        _annRiskEngine = new SimpleAnnRiskEngine();
        _nlpApiService = new NlpApiService();

        _annRiskEngine.Train();
    }

    public async Task<FuzzyRiskResult> AnalyzeWithFuzzyAsync(SensorReading reading)
    {
        await Task.CompletedTask;

        return _fuzzyRiskEngine.Evaluate(
            reading.PoreWaterPressureKPa,
            reading.VibrationAmplitude,
            reading.GroundAccelerationG);
    }

    public async Task<AnnRiskResult> AnalyzeWithAnnAsync(SensorReading reading)
    {
        await Task.CompletedTask;

        return _annRiskEngine.PredictRisk(
            reading.PoreWaterPressureKPa,
            reading.VibrationAmplitude,
            reading.GroundAccelerationG);
    }

    public async Task<string> AskNlpAsync(string prompt)
    {
        return await _nlpApiService.AskAsync(prompt);
    }

    public async Task<AiFinalDecision> GenerateFinalDecisionAsync(SensorReading reading)
    {
        FuzzyRiskResult fuzzyResult = await AnalyzeWithFuzzyAsync(reading);
        AnnRiskResult annResult = await AnalyzeWithAnnAsync(reading);

        double finalScore = (fuzzyResult.RiskScore * 0.6) + (annResult.RiskScore * 0.4);
        finalScore = Math.Round(Math.Clamp(finalScore, 0, 100), 2);

        string finalStatus = GetStatusFromScore(finalScore);

        RiskResult riskResult = new()
        {
            CreatedAt = DateTime.Now,
            FuzzyScore = fuzzyResult.RiskScore,
            AnnScore = annResult.RiskScore,
            FinalRiskScore = finalScore,
            RiskLevel = finalStatus,
            TechnicalExplanation =
                $"Fuzzy={fuzzyResult.RiskScore:F2}; ANN={annResult.RiskScore:F2}; Final={finalScore:F2}",
            MitigationRecommendation = fuzzyResult.MitigationMessage,
            StatusColor = finalStatus
        };

        string nlpText = await _nlpApiService.GenerateMitigationTextAsync(
            riskResult,
            reading);

        return new AiFinalDecision
        {
            FuzzyResult = fuzzyResult,
            AnnResult = annResult,
            RiskResult = riskResult,
            NlpMitigationText = nlpText
        };
    }

    private static string GetStatusFromScore(double score)
    {
        if (score < 40)
            return "Aman";

        if (score < 70)
            return "Waspada";

        return "Bahaya";
    }
}

public class AiFinalDecision
{
    public FuzzyRiskResult FuzzyResult { get; set; } = new();

    public AnnRiskResult AnnResult { get; set; } = new();

    public RiskResult RiskResult { get; set; } = new();

    public string NlpMitigationText { get; set; } = string.Empty;
}