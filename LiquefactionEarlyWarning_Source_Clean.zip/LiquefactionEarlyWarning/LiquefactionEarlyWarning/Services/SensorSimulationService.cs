﻿using LiquefactionEarlyWarning;

namespace LiquefactionEarlyWarning.Services;

public class SensorSimulationService
{
    private readonly Random _random = new();

    /*
     * Service ini digunakan untuk menghasilkan data simulasi sensor.
     * Dalam proyek asli, nilai ini bisa diganti dari sensor tekanan air pori
     * dan sensor piezoelektrik yang dibaca melalui mikrokontroler.
     */

    public SensorReading GenerateNormalCondition()
    {
        return new SensorReading
        {
            Timestamp = DateTime.Now,
            PoreWaterPressureKPa = RandomRange(10, 35),
            VibrationAmplitude = RandomRange(0.05, 0.25),
            GroundAccelerationG = RandomRange(0.01, 0.08),
            PorePressureRatio = RandomRange(0.10, 0.35),
            EffectiveStressKPa = RandomRange(80, 130),
            VibrationFrequencyHz = RandomRange(1, 6),
            TemperatureCelsius = RandomRange(26, 33),
            SoilMoisturePercent = RandomRange(30, 55),
            Source = "Simulation",
            Notes = "Kondisi simulasi aman"
        };
    }

    public SensorReading GenerateWarningCondition()
    {
        return new SensorReading
        {
            Timestamp = DateTime.Now,
            PoreWaterPressureKPa = RandomRange(36, 70),
            VibrationAmplitude = RandomRange(0.26, 0.65),
            GroundAccelerationG = RandomRange(0.09, 0.20),
            PorePressureRatio = RandomRange(0.36, 0.70),
            EffectiveStressKPa = RandomRange(45, 79),
            VibrationFrequencyHz = RandomRange(6, 14),
            TemperatureCelsius = RandomRange(26, 34),
            SoilMoisturePercent = RandomRange(56, 75),
            Source = "Simulation",
            Notes = "Kondisi simulasi waspada"
        };
    }

    public SensorReading GenerateDangerCondition()
    {
        return new SensorReading
        {
            Timestamp = DateTime.Now,
            PoreWaterPressureKPa = RandomRange(71, 120),
            VibrationAmplitude = RandomRange(0.66, 1.20),
            GroundAccelerationG = RandomRange(0.21, 0.45),
            PorePressureRatio = RandomRange(0.71, 1.00),
            EffectiveStressKPa = RandomRange(10, 44),
            VibrationFrequencyHz = RandomRange(14, 30),
            TemperatureCelsius = RandomRange(26, 35),
            SoilMoisturePercent = RandomRange(76, 95),
            Source = "Simulation",
            Notes = "Kondisi simulasi bahaya"
        };
    }

    public SensorReading GenerateRandomReading()
    {
        int scenario = _random.Next(1, 4);

        return scenario switch
        {
            1 => GenerateNormalCondition(),
            2 => GenerateWarningCondition(),
            3 => GenerateDangerCondition(),
            _ => GenerateNormalCondition()
        };
    }

    private double RandomRange(double min, double max)
    {
        double value = min + (_random.NextDouble() * (max - min));
        return Math.Round(value, 3);
    }
}