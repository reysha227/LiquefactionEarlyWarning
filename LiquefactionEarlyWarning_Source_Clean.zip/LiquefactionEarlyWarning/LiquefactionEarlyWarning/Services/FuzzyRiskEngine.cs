﻿namespace LiquefactionEarlyWarning.Services;

public class FuzzyRiskEngine
{
    public FuzzyRiskResult Evaluate(
        double poreWaterPressure,
        double vibration,
        double groundAcceleration)
    {
        try
        {
            /*
             * Input:
             * poreWaterPressure  : tekanan air pori dalam kPa
             * vibration          : amplitudo vibrasi dari piezoelektrik
             * groundAcceleration : percepatan tanah dalam satuan g
             */

            double pressureLow = Low(poreWaterPressure, 25, 45);
            double pressureMedium = Triangle(poreWaterPressure, 35, 60, 85);
            double pressureHigh = High(poreWaterPressure, 70, 95);

            double vibrationLow = Low(vibration, 0.20, 0.40);
            double vibrationMedium = Triangle(vibration, 0.30, 0.60, 0.90);
            double vibrationHigh = High(vibration, 0.75, 1.10);

            double accelerationHigh = High(groundAcceleration, 0.22, 0.35);

            // RULE 1:
            // Tekanan rendah + vibrasi rendah = Aman
            double ruleSafe = Math.Min(pressureLow, vibrationLow);

            // RULE 2:
            // Tekanan sedang + vibrasi sedang = Waspada
            double ruleWarning1 = Math.Min(pressureMedium, vibrationMedium);

            // RULE 4:
            // Tekanan tinggi walaupun vibrasi sedang = minimal Waspada
            double ruleWarning2 = Math.Min(pressureHigh, vibrationMedium);

            // RULE 3:
            // Tekanan tinggi + vibrasi tinggi = Bahaya
            double ruleDanger1 = Math.Min(pressureHigh, vibrationHigh);

            // RULE 5:
            // Percepatan tanah tinggi + tekanan tinggi/naik = Bahaya
            // Karena sistem simulasi belum punya data tekanan sebelumnya,
            // tekanan tinggi dipakai sebagai pendekatan kondisi tekanan naik.
            double pressureRisingApproximation = Math.Max(pressureMedium, pressureHigh);
            double ruleDanger2 = Math.Min(accelerationHigh, pressureRisingApproximation);

            double safeStrength = ruleSafe;
            double warningStrength = Math.Max(ruleWarning1, ruleWarning2);
            double dangerStrength = Math.Max(ruleDanger1, ruleDanger2);

            /*
             * Defuzzifikasi sederhana:
             * Aman    = 20
             * Waspada = 55
             * Bahaya  = 90
             */
            double numerator =
                (safeStrength * 20) +
                (warningStrength * 55) +
                (dangerStrength * 90);

            double denominator =
                safeStrength + warningStrength + dangerStrength;

            double riskScore = denominator <= 0 ? 0 : numerator / denominator;

            // Pengaman tambahan agar kondisi kritis tidak terbaca terlalu rendah.
            if (poreWaterPressure >= 80 && vibration >= 0.60)
                riskScore = Math.Max(riskScore, 75);

            if (groundAcceleration >= 0.25 && poreWaterPressure >= 70)
                riskScore = Math.Max(riskScore, 85);

            riskScore = Math.Round(Math.Clamp(riskScore, 0, 100), 2);

            string status = GetStatusFromScore(riskScore);

            return new FuzzyRiskResult
            {
                RiskScore = riskScore,
                Status = status,
                MitigationMessage = GetMitigationMessage(status)
            };
        }
        catch (Exception ex)
        {
            return new FuzzyRiskResult
            {
                RiskScore = 0,
                Status = "Aman",
                MitigationMessage = $"Fuzzy Logic gagal dihitung. Detail: {ex.Message}"
            };
        }
    }

    private static string GetStatusFromScore(double score)
    {
        if (score < 40)
            return "Aman";

        if (score < 70)
            return "Waspada";

        return "Bahaya";
    }

    private static string GetMitigationMessage(string status)
    {
        return status switch
        {
            "Aman" =>
                "Kondisi aman. Monitoring tekanan air pori dan vibrasi tanah tetap dilakukan secara berkala.",

            "Waspada" =>
                "Kondisi waspada. Tingkatkan frekuensi pemantauan dan siapkan jalur evakuasi awal.",

            "Bahaya" =>
                "Kondisi bahaya. Segera lakukan peringatan dini, evakuasi area rawan, dan hindari tanah retak atau ambles.",

            _ =>
                "Status tidak dikenal. Periksa ulang sensor dan sistem."
        };
    }

    private static double Low(double x, double startDrop, double endDrop)
    {
        if (x <= startDrop)
            return 1.0;

        if (x >= endDrop)
            return 0.0;

        return (endDrop - x) / (endDrop - startDrop);
    }

    private static double High(double x, double startRise, double fullRise)
    {
        if (x <= startRise)
            return 0.0;

        if (x >= fullRise)
            return 1.0;

        return (x - startRise) / (fullRise - startRise);
    }

    private static double Triangle(double x, double left, double center, double right)
    {
        if (x <= left || x >= right)
            return 0.0;

        if (Math.Abs(x - center) < 0.0001)
            return 1.0;

        if (x < center)
            return (x - left) / (center - left);

        return (right - x) / (right - center);
    }
}

public class FuzzyRiskResult
{
    public double RiskScore { get; set; }

    public string Status { get; set; } = "Aman";

    public string MitigationMessage { get; set; } = string.Empty;
}