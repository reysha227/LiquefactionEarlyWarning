using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Views;
using LiquefactionEarlyWarning.Services;

namespace LiquefactionEarlyWarning.Pages;

[QueryProperty(nameof(Username), "username")]
[QueryProperty(nameof(Role), "role")]
public partial class FaceScanPage : ContentPage
{
    private readonly AppDatabase _database;
    private readonly FaceScanService _faceScanService;

    private CancellationTokenSource? _scanCancellationTokenSource;
    private bool _isScanning;
    private int _successStreak;

    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;

    public FaceScanPage()
    {
        InitializeComponent();

        _database = new AppDatabase();
        _faceScanService = new FaceScanService();

        BtnRetry.IsVisible = false;
        BtnBack.IsVisible = false;
    }

    protected override async void OnAppearing()
{
    base.OnAppearing();

    Preferences.Set("is_face_verified", false);

    Username = Uri.UnescapeDataString(Username ?? string.Empty);
    Role = Uri.UnescapeDataString(Role ?? string.Empty);

    LabelUserInfo.Text = $"User: {Username} | Role: {Role}";

    if (!_isScanning)
        await StartFaceScanAsync();
}

    protected override void OnDisappearing()
    {
        base.OnDisappearing();

        StopScanning();
    }

    private async Task StartFaceScanAsync()
    {
        try
        {
            _isScanning = true;
            _successStreak = 0;

            BtnRetry.IsVisible = false;
            BtnBack.IsVisible = false;
            ScanIndicator.IsVisible = true;
            ScanIndicator.IsRunning = true;

            LabelStatus.Text = "Menganalisis wajah...";
            LabelStatus.TextColor = Colors.White;
            LabelSimilarity.Text = "Similarity: 0.00%";

            if (string.IsNullOrWhiteSpace(Username))
            {
                await ShowAccessDeniedAsync("Parameter username tidak ditemukan.");
                return;
            }

            UserAccount? user = await _database.GetUserByUsernameAsync(Username);

            if (user == null)
            {
                await ShowAccessDeniedAsync("Akun tidak ditemukan di database lokal.");
                return;
            }

            byte[]? templateBytes = await LoadTemplateFaceAsync(user);

            if (templateBytes == null || templateBytes.Length == 0)
            {
                await ShowAccessDeniedAsync(
                    "Template wajah tidak ditemukan. Pastikan akun sudah memiliki data wajah di database atau file lokal.");
                return;
            }

            _scanCancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(15));
            CancellationToken token = _scanCancellationTokenSource.Token;

            await StartCameraAsync(token);
            _ = StartScanLineAnimationAsync(token);

            await ScanLoopAsync(templateBytes, token);
        }
        catch (OperationCanceledException)
        {
            if (_successStreak < 3)
                await ShowAccessDeniedAsync("Waktu verifikasi habis. Wajah tidak berhasil cocok dalam 15 detik.");
        }
        catch (Exception ex)
        {
            await ShowAccessDeniedAsync($"Kamera atau proses pemindaian gagal: {ex.Message}");
        }
    }

    private async Task StartCameraAsync(CancellationToken token)
    {
        try
        {
            IReadOnlyList<CameraInfo> cameras = await CameraPreview.GetAvailableCameras(token);

            if (cameras == null || cameras.Count == 0)
                throw new InvalidOperationException("Tidak ada kamera yang terdeteksi pada perangkat.");

            CameraInfo? selectedCamera =
                cameras.FirstOrDefault(x => x.Position == CameraPosition.Front) ??
                cameras.FirstOrDefault();

            if (selectedCamera == null)
                throw new InvalidOperationException("Kamera tidak dapat dipilih.");

            CameraPreview.SelectedCamera = selectedCamera;

            await CameraPreview.StartCameraPreview(token);

            if (!CameraPreview.IsAvailable)
                throw new InvalidOperationException("Preview kamera belum aktif. Cek izin webcam di Package.appxmanifest.");
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                "Kamera tidak aktif. Pastikan izin webcam sudah dicentang dan kamera tidak sedang dipakai aplikasi lain. Detail: " + ex.Message);
        }
    }

    private async Task ScanLoopAsync(byte[] templateBytes, CancellationToken token)
    {
        DateTime startedAt = DateTime.Now;

        while (!token.IsCancellationRequested)
        {
            TimeSpan elapsed = DateTime.Now - startedAt;

            if (elapsed.TotalSeconds >= 15)
                throw new OperationCanceledException();

            try
            {
                using Stream liveFrame = await CaptureFrameAsync(token);

                double similarity = _faceScanService.CalculateSimilarity(templateBytes, liveFrame);

                LabelSimilarity.Text = $"Similarity: {similarity:F2}%";

                if (similarity >= 85.0)
                {
                    _successStreak++;

                    LabelStatus.Text = $"Wajah cocok ({_successStreak}/3)";
                    LabelStatus.TextColor = Color.FromArgb("#00F0FF");
                }
                else
                {
                    _successStreak = 0;

                    LabelStatus.Text = "Menganalisis wajah...";
                    LabelStatus.TextColor = Colors.White;
                }

                if (_successStreak >= 3)
                {
                    await ShowAccessAcceptedAsync(similarity);
                    return;
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch
            {
                LabelStatus.Text = "Frame kamera gagal dibaca, mencoba lagi...";
                LabelStatus.TextColor = Color.FromArgb("#FFB86B");
            }

            await Task.Delay(900, token);
        }
    }

    private async Task<Stream> CaptureFrameAsync(CancellationToken token)
    {
        TaskCompletionSource<Stream> captureCompletion =
            new(TaskCreationOptions.RunContinuationsAsynchronously);

        void OnMediaCaptured(object? sender, MediaCapturedEventArgs e)
        {
            try
            {
                MemoryStream memoryStream = new();

                if (e.Media.CanSeek)
                    e.Media.Position = 0;

                e.Media.CopyTo(memoryStream);
                memoryStream.Position = 0;

                captureCompletion.TrySetResult(memoryStream);
            }
            catch (Exception ex)
            {
                captureCompletion.TrySetException(ex);
            }
        }

        CameraPreview.MediaCaptured += OnMediaCaptured;

        try
        {
            await CameraPreview.CaptureImage(token);

            Stream result = await captureCompletion.Task.WaitAsync(token);
            return result;
        }
        finally
        {
            CameraPreview.MediaCaptured -= OnMediaCaptured;
        }
    }

    private async Task<byte[]?> LoadTemplateFaceAsync(UserAccount user)
    {
        try
        {
            if (user.FaceImageBytes != null && user.FaceImageBytes.Length > 0)
                return user.FaceImageBytes;

            if (!string.IsNullOrWhiteSpace(user.FaceImagePath) && File.Exists(user.FaceImagePath))
                return await File.ReadAllBytesAsync(user.FaceImagePath);

            string fallbackPath = Path.Combine(FileSystem.AppDataDirectory, $"{user.Username}_face.png");

            if (File.Exists(fallbackPath))
                return await File.ReadAllBytesAsync(fallbackPath);

            return null;
        }
        catch
        {
            return null;
        }
    }

    private async Task ShowAccessAcceptedAsync(double similarity)
    {
        try
        {
            StopScanning();

            ScanIndicator.IsRunning = false;
            ScanIndicator.IsVisible = false;

            LabelStatus.Text = "Akses diterima";
            LabelStatus.TextColor = Color.FromArgb("#00F0FF");
            LabelSimilarity.Text = $"Similarity: {similarity:F2}%";

            await Task.Delay(900);

            Preferences.Set("is_face_verified", true);

            await Shell.Current.GoToAsync("MainDashboardPage");
        }
        catch (Exception ex)
        {
            await DisplayAlert(
                "Navigasi Gagal",
                $"Akses diterima, tetapi halaman dashboard belum siap atau route belum terdaftar. Detail: {ex.Message}",
                "OK");

            BtnRetry.IsVisible = true;
            BtnBack.IsVisible = true;
        }
    }

    private async Task ShowAccessDeniedAsync(string message)
    {
        StopScanning();

        ScanIndicator.IsRunning = false;
        ScanIndicator.IsVisible = false;

        LabelStatus.Text = "Akses ditolak";
        LabelStatus.TextColor = Color.FromArgb("#FF5CA8");

        BtnRetry.IsVisible = true;
        BtnBack.IsVisible = true;

        await DisplayAlert("Verifikasi Gagal", message, "OK");
    }

    private async Task StartScanLineAnimationAsync(CancellationToken token)
    {
        try
        {
            while (!token.IsCancellationRequested)
            {
                ScanLine.TranslationY = 0;
                await ScanLine.TranslateTo(0, 360, 1200, Easing.CubicInOut);
                await ScanLine.TranslateTo(0, 0, 1200, Easing.CubicInOut);
            }
        }
        catch
        {
            // Animasi berhenti saat halaman ditutup atau scanning selesai.
        }
    }

    private void StopScanning()
    {
        try
        {
            _scanCancellationTokenSource?.Cancel();
            _scanCancellationTokenSource?.Dispose();
            _scanCancellationTokenSource = null;

            if (CameraPreview.IsAvailable)
                CameraPreview.StopCameraPreview();
        }
        catch
        {
            // Abaikan error saat cleanup kamera.
        }
        finally
        {
            _isScanning = false;
        }
    }

    private async void OnRetryClicked(object sender, EventArgs e)
    {
        if (_isScanning)
            return;

        await StartFaceScanAsync();
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        try
        {
            StopScanning();

            await Shell.Current.GoToAsync("..");
        }
        catch
        {
            await Shell.Current.GoToAsync("//RegisterPage");
        }
    }
}