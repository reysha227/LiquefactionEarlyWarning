using System.Collections.ObjectModel;
using LiquefactionEarlyWarning;
using LiquefactionEarlyWarning.Services;

namespace LiquefactionEarlyWarning.Pages;

public partial class MainDashboardPage : ContentPage
{
    private readonly MonitoringLocationService _locationService = new();
    private readonly FuzzyRiskEngine _fuzzyEngine = new();
    private readonly SimpleAnnRiskEngine _annEngine = new();
    private readonly NlpApiService _nlpService = new();
    private readonly NlpAccessPolicy _nlpAccessPolicy = new();
    private readonly AppDatabase _database = new();

    private readonly ObservableCollection<LocationStatusItem> _locationItems = new();
    private readonly ObservableCollection<IncidentLogItem> _incidentLogs = new();
    private readonly ObservableCollection<TrendBarItem> _trendBars = new();

    private SensorReading? _latestReading;
    private FuzzyRiskResult? _latestFuzzyResult;
    private AnnRiskResult? _latestAnnResult;
    private MonitoringLocationData? _latestLocation;

    private double _latestFinalRiskScore;
    private string _latestFinalStatus = "Aman";
    private string _latestMitigationText = string.Empty;

    public MainDashboardPage()
    {
        InitializeComponent();

        _annEngine.Train();

        LocationCollection.ItemsSource = _locationItems;
        IncidentCollection.ItemsSource = _incidentLogs;
        TrendCollection.ItemsSource = _trendBars;

        InitializeDashboard();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        bool isFaceVerified = Preferences.Get("is_face_verified", false);
        string role = Preferences.Get("session_role", string.Empty);

        if (!_nlpAccessPolicy.CanAccessDashboardNlp(isFaceVerified, role))
        {
            await DisplayAlert(
                "Akses Ditolak",
                "Dashboard hanya dapat dibuka setelah login dan verifikasi wajah berhasil.",
                "OK");

            await GoToLoginAsync();
            return;
        }

        LabelRole.Text = $"Role: {role}";

        await RunAnalysisAsync();
    }

    private void InitializeDashboard()
    {
        _locationItems.Clear();

        foreach (MonitoringLocationData location in _locationService.GetAllLocations())
        {
            _locationItems.Add(new LocationStatusItem
            {
                Name = location.Name,
                Coordinate = location.Coordinate,
                StatusText = "Menunggu analisis",
                DotColor = Color.FromArgb("#7C8DB9")
            });
        }

        _trendBars.Clear();

        for (int i = 0; i < 12; i++)
        {
            _trendBars.Add(new TrendBarItem
            {
                Height = 20,
                BarColor = Color.FromArgb("#223252")
            });
        }

        UpdateActiveLocationInfo(_locationService.GetActiveLocation());
        ResetBars();
    }

    public async void OnAnalyzeClicked(object? sender, EventArgs e)
    {
        await RunAnalysisAsync();
    }

    public async void OnNextLocationClicked(object? sender, EventArgs e)
    {
        MonitoringLocationData location = _locationService.MoveNextLocation();
        UpdateActiveLocationInfo(location);
        await RunAnalysisAsync();
    }

    private async Task RunAnalysisAsync()
    {
        try
        {
            MonitoringLocationData location = _locationService.GetActiveLocation();
            SensorReading reading = _locationService.GenerateReadingForLocation(location);

            FuzzyRiskResult fuzzyResult = _fuzzyEngine.Evaluate(
                reading.PoreWaterPressureKPa,
                reading.VibrationAmplitude,
                reading.GroundAccelerationG);

            AnnRiskResult annResult = _annEngine.PredictRisk(
                reading.PoreWaterPressureKPa,
                reading.VibrationAmplitude,
                reading.GroundAccelerationG);

            double finalRiskScore =
                (fuzzyResult.RiskScore * 0.6) +
                (annResult.RiskScore * 0.4);

            finalRiskScore = Math.Round(Math.Clamp(finalRiskScore, 0, 100), 2);

            string finalStatus = GetStatusFromScore(finalRiskScore);

            string explanation = await _nlpService.ExplainRiskAsync(
                finalStatus,
                finalRiskScore,
                reading.PoreWaterPressureKPa,
                reading.VibrationAmplitude,
                reading.GroundAccelerationG);

            explanation =
                $"Lokasi aktif: {location.Name}\n" +
                $"Koordinat: {location.Coordinate}\n" +
                $"Jenis area: {location.AreaType}\n\n" +
                explanation;

            _latestReading = reading;
            _latestFuzzyResult = fuzzyResult;
            _latestAnnResult = annResult;
            _latestLocation = location;
            _latestFinalRiskScore = finalRiskScore;
            _latestFinalStatus = finalStatus;
            _latestMitigationText = explanation;

            UpdateActiveLocationInfo(location);
            UpdateSensorLabels(reading, fuzzyResult, annResult, finalRiskScore, finalStatus, explanation);
            UpdateBars(reading, fuzzyResult, annResult, finalRiskScore);
            UpdateLocationStatus(location, finalStatus, finalRiskScore);
            UpdateMapMarkers(location, finalStatus);
            AddIncidentLog(location, reading, finalStatus, finalRiskScore);
        }
        catch (Exception ex)
        {
            await DisplayAlert(
                "Error Analisis",
                $"Analisis gagal: {ex.Message}",
                "OK");
        }
    }

    private void UpdateActiveLocationInfo(MonitoringLocationData location)
    {
        LabelLocation.Text = $"Lokasi aktif: {location.Name}";
        LabelCoordinate.Text = $"Koordinat: {location.Coordinate}";
        LabelAreaType.Text = $"Jenis area: {location.AreaType}";
        LabelLocationDescription.Text = location.Description;
        LabelTimestamp.Text = $"Waktu: {DateTime.Now:dd/MM/yyyy HH:mm:ss}";
    }

    private void UpdateSensorLabels(
        SensorReading reading,
        FuzzyRiskResult fuzzyResult,
        AnnRiskResult annResult,
        double finalRiskScore,
        string finalStatus,
        string explanation)
    {
        LabelPressure.Text = $"{reading.PoreWaterPressureKPa:F2} kPa";
        LabelVibration.Text = $"{reading.VibrationAmplitude:F3}";
        LabelAcceleration.Text = $"{reading.GroundAccelerationG:F3} g";
        LabelRiskScore.Text = $"{finalRiskScore:F2} / 100";
        LabelStatus.Text = $"Status: {finalStatus}";
        LabelMitigation.Text = explanation;

        LabelFuzzyScore.Text = $"Fuzzy: {fuzzyResult.RiskScore:F1}";
        LabelAnnScore.Text = $"ANN: {annResult.RiskScore:F1}";
        LabelFinalScore.Text = $"Final: {finalRiskScore:F1}";

        Color statusColor = GetStatusColor(finalStatus);
        LabelStatus.TextColor = statusColor;
        LabelRiskScore.TextColor = statusColor;
    }

    private void UpdateBars(
        SensorReading reading,
        FuzzyRiskResult fuzzyResult,
        AnnRiskResult annResult,
        double finalRiskScore)
    {
        BarPressure.HeightRequest = ClampBar(reading.PoreWaterPressureKPa / 120.0 * 150.0);
        BarVibration.HeightRequest = ClampBar(reading.VibrationAmplitude / 1.3 * 150.0);
        BarAcceleration.HeightRequest = ClampBar(reading.GroundAccelerationG / 0.45 * 150.0);

        BarFuzzy.HeightRequest = ClampBar(fuzzyResult.RiskScore / 100.0 * 130.0);
        BarAnn.HeightRequest = ClampBar(annResult.RiskScore / 100.0 * 130.0);
        BarFinal.HeightRequest = ClampBar(finalRiskScore / 100.0 * 130.0);

        _trendBars.Add(new TrendBarItem
        {
            Height = ClampBar(finalRiskScore / 100.0 * 95.0),
            BarColor = GetStatusColor(GetStatusFromScore(finalRiskScore))
        });

        while (_trendBars.Count > 12)
            _trendBars.RemoveAt(0);
    }

    private void ResetBars()
    {
        BarPressure.HeightRequest = 28;
        BarVibration.HeightRequest = 28;
        BarAcceleration.HeightRequest = 28;
        BarFuzzy.HeightRequest = 28;
        BarAnn.HeightRequest = 28;
        BarFinal.HeightRequest = 28;
    }

    private static double ClampBar(double value)
    {
        return Math.Clamp(value, 18, 150);
    }

    private void UpdateLocationStatus(MonitoringLocationData activeLocation, string status, double score)
    {
        foreach (LocationStatusItem item in _locationItems)
        {
            if (item.Name == activeLocation.Name)
            {
                item.StatusText = $"{status} | Risk {score:F1}/100";
                item.DotColor = GetStatusColor(status);
            }
        }
    }

    private void UpdateMapMarkers(MonitoringLocationData location, string status)
    {
        Color defaultStroke = Color.FromArgb("#42E6A4");
        Color activeStroke = GetStatusColor(status);

        MapMarkerA.Stroke = defaultStroke;
        MapMarkerB.Stroke = defaultStroke;
        MapMarkerC.Stroke = defaultStroke;
        MapMarkerD.Stroke = defaultStroke;

        if (location.Code == "A") MapMarkerA.Stroke = activeStroke;
        if (location.Code == "B") MapMarkerB.Stroke = activeStroke;
        if (location.Code == "C") MapMarkerC.Stroke = activeStroke;
        if (location.Code == "D") MapMarkerD.Stroke = activeStroke;
    }

    private void AddIncidentLog(
        MonitoringLocationData location,
        SensorReading reading,
        string status,
        double score)
    {
        _incidentLogs.Insert(0, new IncidentLogItem
        {
            Title = $"{status} - {location.Name}",
            Detail = $"PWP {reading.PoreWaterPressureKPa:F1} kPa | Vib {reading.VibrationAmplitude:F2} | Acc {reading.GroundAccelerationG:F2} g | Risk {score:F1}",
            TimeText = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")
        });

        while (_incidentLogs.Count > 8)
            _incidentLogs.RemoveAt(_incidentLogs.Count - 1);
    }

    public async void OnSaveClicked(object? sender, EventArgs e)
    {
        try
        {
            if (_latestReading == null ||
                _latestFuzzyResult == null ||
                _latestAnnResult == null ||
                _latestLocation == null)
            {
                await DisplayAlert(
                    "Data Kosong",
                    "Lakukan analisis terlebih dahulu sebelum menyimpan data.",
                    "OK");

                return;
            }

            await _database.SaveSensorReadingAsync(_latestReading);

            RiskResult riskResult = new()
            {
                SensorReadingId = _latestReading.Id,
                CreatedAt = DateTime.Now,
                FuzzyScore = _latestFuzzyResult.RiskScore,
                AnnScore = _latestAnnResult.RiskScore,
                FinalRiskScore = _latestFinalRiskScore,
                RiskLevel = _latestFinalStatus,
                TechnicalExplanation =
                    $"Lokasi={_latestLocation.Name}; " +
                    $"Koordinat={_latestLocation.Coordinate}; " +
                    $"Fuzzy={_latestFuzzyResult.RiskScore:F2}; " +
                    $"ANN={_latestAnnResult.RiskScore:F2}; " +
                    $"Final={_latestFinalRiskScore:F2}",
                MitigationRecommendation = _latestMitigationText,
                StatusColor = _latestFinalStatus
            };

            await _database.SaveRiskResultAsync(riskResult);

            await DisplayAlert(
                "Berhasil",
                "Data monitoring lokasi, sensor, dan hasil AI berhasil disimpan ke SQLite.",
                "OK");
        }
        catch (Exception ex)
        {
            await DisplayAlert(
                "Gagal Menyimpan",
                $"Data gagal disimpan: {ex.Message}",
                "OK");
        }
    }

    public async void OnBackToLoginClicked(object? sender, EventArgs e)
    {
        await GoToLoginAsync();
    }

    public async void OnLogoutClicked(object? sender, EventArgs e)
    {
        await GoToLoginAsync();
    }

    private async Task GoToLoginAsync()
    {
        Preferences.Remove("session_username");
        Preferences.Remove("session_role");
        Preferences.Set("is_face_verified", false);

        await Shell.Current.GoToAsync("//RegisterPage");
    }

    private static string GetStatusFromScore(double score)
    {
        if (score < 40)
            return "Aman";

        if (score < 70)
            return "Waspada";

        return "Bahaya";
    }

    private static Color GetStatusColor(string status)
    {
        return status switch
        {
            "Aman" => Color.FromArgb("#42E6A4"),
            "Waspada" => Color.FromArgb("#FFB86B"),
            "Bahaya" => Color.FromArgb("#FF5CA8"),
            _ => Color.FromArgb("#00F0FF")
        };
    }
}

public class LocationStatusItem
{
    public string Name { get; set; } = string.Empty;
    public string Coordinate { get; set; } = string.Empty;
    public string StatusText { get; set; } = string.Empty;
    public Color DotColor { get; set; } = Colors.White;
}

public class IncidentLogItem
{
    public string Title { get; set; } = string.Empty;
    public string Detail { get; set; } = string.Empty;
    public string TimeText { get; set; } = string.Empty;
}

public class TrendBarItem
{
    public double Height { get; set; }
    public Color BarColor { get; set; } = Colors.White;
}
