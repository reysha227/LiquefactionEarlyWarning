using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Views;
using static System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy;

namespace LiquefactionEarlyWarning.Pages;

[QueryProperty(nameof(Username), "username")]
[QueryProperty(nameof(Role), "role")]
public partial class FaceEnrollPage : ContentPage
{
    private readonly AppDatabase _database = new();

    private bool _isCameraStarted;
    private bool _isProcessing;

    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;

    public FaceEnrollPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        Username = Uri.UnescapeDataString(Username ?? string.Empty);
        Role = Uri.UnescapeDataString(Role ?? string.Empty);

        LabelInfo.Text = $"Akun: {Username} | Role: {Role}\nArahkan wajah ke kamera lalu klik Simpan Template Wajah.";

        await StartCameraAsync();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();

        StopCamera();
    }

    private async Task StartCameraAsync()
    {
        try
        {
            if (_isCameraStarted)
                return;

            using CancellationTokenSource cts = new(TimeSpan.FromSeconds(10));

            IReadOnlyList<CameraInfo> cameras = await CameraPreview.GetAvailableCameras(cts.Token);

            if (cameras == null || cameras.Count == 0)
            {
                await DisplayAlertAsync("Kamera Tidak Ditemukan", "Tidak ada kamera yang terdeteksi.", "OK");
                return;
            }

            CameraInfo? selectedCamera =
                cameras.FirstOrDefault(x => x.Position == CameraPosition.Front) ??
                cameras.FirstOrDefault();

            if (selectedCamera == null)
            {
                await DisplayAlertAsync("Kamera Error", "Kamera tidak dapat dipilih.", "OK");
                return;
            }

            CameraPreview.SelectedCamera = selectedCamera;

            await CameraPreview.StartCameraPreview(cts.Token);

            _isCameraStarted = true;
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync(
                "Kamera Gagal Aktif",
                $"Pastikan izin webcam sudah aktif dan kamera tidak sedang dipakai aplikasi lain.\n\nDetail: {ex.Message}",
                "OK");
        }
    }

    private async void OnCaptureClicked(object? sender, EventArgs e)
    {
        if (_isProcessing)
            return;

        try
        {
            _isProcessing = true;
            SetBusy(true);

            if (string.IsNullOrWhiteSpace(Username))
            {
                await DisplayAlertAsync("Data Tidak Lengkap", "Username tidak ditemukan.", "OK");
                return;
            }

            UserAccount? user = await _database.GetUserByUsernameAsync(Username);

            if (user == null)
            {
                await DisplayAlertAsync("Akun Tidak Ditemukan", "Data akun tidak ditemukan di SQLite.", "OK");
                return;
            }

            byte[] faceBytes = await CaptureCurrentFaceAsync();

            if (faceBytes.Length == 0)
            {
                await DisplayAlertAsync("Capture Gagal", "Gambar wajah gagal diambil.", "OK");
                return;
            }

            string fileName = $"{Username}_face.png";
            string filePath = Path.Combine(FileSystem.AppDataDirectory, fileName);

            await File.WriteAllBytesAsync(filePath, faceBytes);

            user.FaceImageBytes = faceBytes;
            user.FaceImagePath = filePath;
            user.UpdatedAt = DateTime.Now;

            await _database.SaveUserAsync(user);

            await DisplayAlertAsync(
                "Template Wajah Tersimpan",
                "Template wajah berhasil disimpan. Sekarang kamu bisa login menggunakan akun tersebut.",
                "OK");

            StopCamera();

            await Shell.Current.GoToAsync("//RegisterPage");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Gagal Menyimpan Wajah", $"Terjadi kesalahan: {ex.Message}", "OK");
        }
        finally
        {
            SetBusy(false);
            _isProcessing = false;
        }
    }

    private async Task<byte[]> CaptureCurrentFaceAsync()
    {
        TaskCompletionSource<byte[]> tcs =
            new(TaskCreationOptions.RunContinuationsAsynchronously);

        void OnMediaCaptured(object? sender, MediaCapturedEventArgs e)
        {
            try
            {
                using MemoryStream memoryStream = new();

                if (e.Media.CanSeek)
                    e.Media.Position = 0;

                e.Media.CopyTo(memoryStream);

                tcs.TrySetResult(memoryStream.ToArray());
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        }

        CameraPreview.MediaCaptured += OnMediaCaptured;

        try
        {
            using CancellationTokenSource cts = new(TimeSpan.FromSeconds(10));

            await CameraPreview.CaptureImage(cts.Token);

            byte[] result = await tcs.Task.WaitAsync(cts.Token);

            return result;
        }
        finally
        {
            CameraPreview.MediaCaptured -= OnMediaCaptured;
        }
    }

    private void StopCamera()
    {
        try
        {
            if (_isCameraStarted)
            {
                CameraPreview.StopCameraPreview();
                _isCameraStarted = false;
            }
        }
        catch
        {
            // Abaikan error saat kamera ditutup.
        }
    }

    private async void OnBackClicked(object? sender, EventArgs e)
    {
        try
        {
            StopCamera();

            await Shell.Current.GoToAsync("//RegisterPage");
        }
        catch
        {
            Application.Current!.MainPage = new AppShell();
        }
    }

    private void SetBusy(bool value)
    {
        BtnCapture.IsEnabled = !value;
        BtnBack.IsEnabled = !value;

        LoadingIndicator.IsVisible = value;
        LoadingIndicator.IsRunning = value;
    }
}