using LiquefactionEarlyWarning;
using LiquefactionEarlyWarning.Services;

namespace LiquefactionEarlyWarning.Pages;

public partial class RegisterPage : ContentPage
{
    private readonly AppDatabase _database;
    private readonly AuthService _authService;
    private readonly NlpApiService _nlpApiService;
    private readonly NlpAccessPolicy _nlpAccessPolicy;

    private bool _isProcessing;

    public RegisterPage()
    {
        InitializeComponent();

        _database = new AppDatabase();
        _authService = new AuthService(_database);
        _nlpApiService = new NlpApiService();
        _nlpAccessPolicy = new NlpAccessPolicy();

        RadioPetugas.IsChecked = true;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        EntryPassword.Text = string.Empty;
    }

    private string SelectedRole
    {
        get
        {
            if (RadioPetugas.IsChecked)
                return "Petugas Lapangan";

            if (RadioWarga.IsChecked)
                return "Warga Sipil";

            return "Warga Sipil";
        }
    }

    private async void OnRegisterClicked(object sender, EventArgs e)
    {
        if (_isProcessing)
            return;

        try
        {
            await SetBusyAsync(true);

            string username = EntryUsername.Text?.Trim() ?? string.Empty;
            string password = EntryPassword.Text ?? string.Empty;
            string role = SelectedRole;

            if (string.IsNullOrWhiteSpace(username))
            {
                await DisplayAlertAsync("Data Belum Lengkap", "Nama pengguna wajib diisi.", "OK");
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                await DisplayAlertAsync("Data Belum Lengkap", "Kata sandi wajib diisi.", "OK");
                return;
            }

            if (password.Length < 4)
            {
                await DisplayAlertAsync("Kata Sandi Lemah", "Kata sandi minimal 4 karakter.", "OK");
                return;
            }

            var result = await _authService.RegisterAsync(username, password, role);

            if (!result.Success)
            {
                await DisplayAlertAsync("Registrasi Gagal", result.Message, "OK");
                return;
            }

            await DisplayAlertAsync(
                "Registrasi Berhasil",
                "Akun berhasil dibuat. Selanjutnya simpan template wajah untuk verifikasi login.",
                "OK");

            string safeUsername = Uri.EscapeDataString(username);
            string safeRole = Uri.EscapeDataString(role);

            ClearForm();

            await Shell.Current.GoToAsync($"FaceEnrollPage?username={safeUsername}&role={safeRole}");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Error Registrasi", $"Terjadi kesalahan: {ex.Message}", "OK");
        }
        finally
        {
            await SetBusyAsync(false);
        }
    }

    private async void OnLoginClicked(object sender, EventArgs e)
    {
        if (_isProcessing)
            return;

        try
        {
            await SetBusyAsync(true);

            string username = EntryUsername.Text?.Trim() ?? string.Empty;
            string password = EntryPassword.Text ?? string.Empty;
            string role = SelectedRole;

            if (string.IsNullOrWhiteSpace(username))
            {
                await DisplayAlertAsync("Login Gagal", "Nama pengguna wajib diisi.", "OK");
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                await DisplayAlertAsync("Login Gagal", "Kata sandi wajib diisi.", "OK");
                return;
            }

            var result = await _authService.LoginAsync(username, password, role);

            if (!result.Success || result.User == null)
            {
                await DisplayAlertAsync("Login Gagal", result.Message, "OK");
                return;
            }

            Preferences.Set("session_username", result.User.Username);
            Preferences.Set("session_role", result.User.Role);
            Preferences.Set("is_face_verified", false);

            string safeUsername = Uri.EscapeDataString(result.User.Username);
            string safeRole = Uri.EscapeDataString(result.User.Role);

            await Shell.Current.GoToAsync($"FaceScanPage?username={safeUsername}&role={safeRole}");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Error Login", $"Terjadi kesalahan: {ex.Message}", "OK");
        }
        finally
        {
            await SetBusyAsync(false);
        }
    }

    private async void OnNlpInfoClicked(object sender, EventArgs e)
    {
        if (_isProcessing)
            return;

        try
        {
            await SetBusyAsync(true);

            bool isLoggedIn = Preferences.ContainsKey("session_username");
            bool canAccessPublicInfo = _nlpAccessPolicy.CanAccessPublicInfo(isLoggedIn);

            if (!canAccessPublicInfo)
            {
                await DisplayAlertAsync(
                    "Akses Ditolak",
                    "Informasi publik tidak dapat dibuka.",
                    "OK");

                return;
            }

            string question =
                "Jelaskan informasi umum tentang likuefaksi, tekanan air pori, " +
                "vibrasi tanah dari sensor piezoelektrik, dan mitigasi awal saat gempa. " +
                "Jawab sebagai informasi publik. Jangan membuka dashboard, jangan membaca data sensor, " +
                "dan jangan melewati login atau verifikasi wajah.";

            string answer = await _nlpApiService.GeneratePublicInfoAsync(question);

            await DisplayAlertAsync(
                "Bantuan AI / Info Mitigasi",
                answer,
                "Saya Mengerti");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync(
                "Error NLP",
                $"Informasi mitigasi gagal dibuka: {ex.Message}",
                "OK");
        }
        finally
        {
            await SetBusyAsync(false);
        }
    }

    private async Task SetBusyAsync(bool value)
    {
        _isProcessing = value;

        BtnRegister.IsEnabled = !value;
        BtnLogin.IsEnabled = !value;
        BtnNlpInfo.IsEnabled = !value;

        LoadingIndicator.IsVisible = value;
        LoadingIndicator.IsRunning = value;

        await Task.CompletedTask;
    }

    private void ClearForm()
    {
        EntryUsername.Text = string.Empty;
        EntryPassword.Text = string.Empty;

        RadioPetugas.IsChecked = true;
        RadioWarga.IsChecked = false;
    }
}