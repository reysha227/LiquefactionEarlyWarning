﻿using SQLite;

namespace LiquefactionEarlyWarning;

public class AppDatabase
{
    private const string DatabaseFileName = "LiquefactionEarlyWarning.db3";

    private static readonly SQLiteOpenFlags Flags =
        SQLiteOpenFlags.ReadWrite |
        SQLiteOpenFlags.Create |
        SQLiteOpenFlags.SharedCache;

    private readonly SQLiteAsyncConnection _database;
    private readonly SemaphoreSlim _initLock = new(1, 1);

    private bool _isInitialized;

    public static string DatabasePath =>
        Path.Combine(FileSystem.AppDataDirectory, DatabaseFileName);

    public AppDatabase()
    {
        _database = new SQLiteAsyncConnection(DatabasePath, Flags);
    }

    private async Task InitAsync()
    {
        if (_isInitialized)
            return;

        await _initLock.WaitAsync();

        try
        {
            if (_isInitialized)
                return;

            await _database.CreateTableAsync<UserAccount>();
            await _database.CreateTableAsync<SensorReading>();
            await _database.CreateTableAsync<RiskResult>();
            await _database.CreateTableAsync<NlpResponse>();

            _isInitialized = true;
        }
        finally
        {
            _initLock.Release();
        }
    }

    // =========================
    // USER ACCOUNT
    // =========================

    public async Task<int> SaveUserAsync(UserAccount user)
    {
        await InitAsync();

        user.UpdatedAt = DateTime.Now;

        if (user.Id != 0)
            return await _database.UpdateAsync(user);

        user.CreatedAt = DateTime.Now;
        return await _database.InsertAsync(user);
    }

    public async Task<UserAccount?> GetUserByUsernameAsync(string username)
    {
        await InitAsync();

        return await _database
            .Table<UserAccount>()
            .Where(x => x.Username == username)
            .FirstOrDefaultAsync();
    }

    public async Task<List<UserAccount>> GetAllUsersAsync()
    {
        await InitAsync();

        return await _database
            .Table<UserAccount>()
            .OrderBy(x => x.Username)
            .ToListAsync();
    }

    public async Task<int> DeleteUserAsync(UserAccount user)
    {
        await InitAsync();

        return await _database.DeleteAsync(user);
    }

    // =========================
    // SENSOR READING
    // =========================

    public async Task<int> SaveSensorReadingAsync(SensorReading reading)
    {
        await InitAsync();

        if (reading.Id != 0)
            return await _database.UpdateAsync(reading);

        reading.Timestamp = DateTime.Now;
        return await _database.InsertAsync(reading);
    }

    public async Task<SensorReading?> GetSensorReadingByIdAsync(int id)
    {
        await InitAsync();

        return await _database
            .Table<SensorReading>()
            .Where(x => x.Id == id)
            .FirstOrDefaultAsync();
    }

    public async Task<SensorReading?> GetLatestSensorReadingAsync()
    {
        await InitAsync();

        return await _database
            .Table<SensorReading>()
            .OrderByDescending(x => x.Timestamp)
            .FirstOrDefaultAsync();
    }

    public async Task<List<SensorReading>> GetRecentSensorReadingsAsync(int limit = 50)
    {
        await InitAsync();

        return await _database
            .Table<SensorReading>()
            .OrderByDescending(x => x.Timestamp)
            .Take(limit)
            .ToListAsync();
    }

    public async Task<List<SensorReading>> GetSensorReadingsByDateAsync(DateTime date)
    {
        await InitAsync();

        DateTime start = date.Date;
        DateTime end = start.AddDays(1);

        return await _database
            .Table<SensorReading>()
            .Where(x => x.Timestamp >= start && x.Timestamp < end)
            .OrderByDescending(x => x.Timestamp)
            .ToListAsync();
    }

    public async Task<int> DeleteSensorReadingAsync(SensorReading reading)
    {
        await InitAsync();

        return await _database.DeleteAsync(reading);
    }

    // =========================
    // RISK RESULT
    // =========================

    public async Task<int> SaveRiskResultAsync(RiskResult result)
    {
        await InitAsync();

        if (result.Id != 0)
            return await _database.UpdateAsync(result);

        result.CreatedAt = DateTime.Now;
        return await _database.InsertAsync(result);
    }

    public async Task<RiskResult?> GetRiskResultByIdAsync(int id)
    {
        await InitAsync();

        return await _database
            .Table<RiskResult>()
            .Where(x => x.Id == id)
            .FirstOrDefaultAsync();
    }

    public async Task<RiskResult?> GetLatestRiskResultAsync()
    {
        await InitAsync();

        return await _database
            .Table<RiskResult>()
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync();
    }

    public async Task<List<RiskResult>> GetRiskResultsBySensorReadingIdAsync(int sensorReadingId)
    {
        await InitAsync();

        return await _database
            .Table<RiskResult>()
            .Where(x => x.SensorReadingId == sensorReadingId)
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync();
    }

    public async Task<List<RiskResult>> GetRecentRiskResultsAsync(int limit = 50)
    {
        await InitAsync();

        return await _database
            .Table<RiskResult>()
            .OrderByDescending(x => x.CreatedAt)
            .Take(limit)
            .ToListAsync();
    }

    public async Task<int> DeleteRiskResultAsync(RiskResult result)
    {
        await InitAsync();

        return await _database.DeleteAsync(result);
    }

    // =========================
    // NLP RESPONSE
    // =========================

    public async Task<int> SaveNlpResponseAsync(NlpResponse response)
    {
        await InitAsync();

        if (response.Id != 0)
            return await _database.UpdateAsync(response);

        response.CreatedAt = DateTime.Now;
        return await _database.InsertAsync(response);
    }

    public async Task<NlpResponse?> GetNlpResponseByRiskResultIdAsync(int riskResultId)
    {
        await InitAsync();

        return await _database
            .Table<NlpResponse>()
            .Where(x => x.RiskResultId == riskResultId)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync();
    }

    public async Task<List<NlpResponse>> GetRecentNlpResponsesAsync(int limit = 30)
    {
        await InitAsync();

        return await _database
            .Table<NlpResponse>()
            .OrderByDescending(x => x.CreatedAt)
            .Take(limit)
            .ToListAsync();
    }

    public async Task<int> DeleteNlpResponseAsync(NlpResponse response)
    {
        await InitAsync();

        return await _database.DeleteAsync(response);
    }

    // =========================
    // UTILITY
    // =========================

    public async Task ClearAllDataAsync()
    {
        await InitAsync();

        await _database.DeleteAllAsync<NlpResponse>();
        await _database.DeleteAllAsync<RiskResult>();
        await _database.DeleteAllAsync<SensorReading>();
        await _database.DeleteAllAsync<UserAccount>();
    }
}