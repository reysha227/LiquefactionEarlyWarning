﻿using SQLite;

namespace LiquefactionEarlyWarning;

public class UserAccount
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    // Username dibuat unik agar tidak ada akun ganda.
    // Jangan pakai [Unique, Indexed] karena bisa memicu error SQLite index.
    [Indexed(Unique = true)]
    public string Username { get; set; } = string.Empty;

    public string PasswordHash { get; set; } = string.Empty;

    public string FullName { get; set; } = string.Empty;

    // Role:
    // Petugas Lapangan
    // Warga Sipil
    public string Role { get; set; } = "Warga Sipil";

    public string FaceImagePath { get; set; } = string.Empty;

    public byte[]? FaceImageBytes { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}