﻿using SQLite;

namespace LiquefactionEarlyWarning;

public class SensorReading
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [Indexed]
    public DateTime Timestamp { get; set; } = DateTime.Now;

    public double PoreWaterPressureKPa { get; set; }

    public double EffectiveStressKPa { get; set; }

    public double PorePressureRatio { get; set; }

    public double VibrationAmplitude { get; set; }

    public double VibrationFrequencyHz { get; set; }

    public double GroundAccelerationG { get; set; }

    public double TemperatureCelsius { get; set; }

    public double SoilMoisturePercent { get; set; }

    public string Source { get; set; } = "Simulation";

    public string Notes { get; set; } = string.Empty;
}