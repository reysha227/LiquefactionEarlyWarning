﻿using SQLite;

namespace LiquefactionEarlyWarning;

public class RiskResult
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    // Relasi sederhana ke tabel SensorReading
    [Indexed]
    public int SensorReadingId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    // Skor dari fuzzy logic, 0-100
    public double FuzzyScore { get; set; }

    // Skor dari ANN sederhana, 0-100
    public double AnnScore { get; set; }

    // Skor akhir gabungan Fuzzy + ANN, 0-100
    public double FinalRiskScore { get; set; }

    // Contoh:
    // Aman
    // Waspada
    // Bahaya
    public string RiskLevel { get; set; } = "Aman";

    // Penjelasan teknis singkat
    public string TechnicalExplanation { get; set; } = string.Empty;

    // Rekomendasi sederhana untuk orang awam
    public string MitigationRecommendation { get; set; } = string.Empty;

    // Warna status untuk UI dashboard
    // Hijau, Kuning, Merah
    public string StatusColor { get; set; } = "Hijau";

    public bool IsSentToNlp { get; set; } = false;
}