﻿using SQLite;

namespace LiquefactionEarlyWarning;

public class NlpResponse
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    // Relasi sederhana ke hasil risiko
    [Indexed]
    public int RiskResultId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    // Contoh:
    // OpenAI
    // Gemini
    // DeepSeek
    // LocalFallback
    public string ProviderName { get; set; } = "LocalFallback";

    // Prompt yang dikirim ke API NLP
    public string PromptText { get; set; } = string.Empty;

    // Jawaban API NLP
    public string ResponseText { get; set; } = string.Empty;

    // Penjelasan versi sederhana untuk masyarakat umum
    public string SimpleExplanation { get; set; } = string.Empty;

    // Status request API
    public bool IsSuccess { get; set; } = false;

    public string ErrorMessage { get; set; } = string.Empty;
}